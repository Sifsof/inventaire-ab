import { InventoryItem, MatchPair, MatchStatus, ReconciliationSummary, ProbableCause } from '../types/inventory';

/**
 * Clean and normalize a string for semantic comparison
 */
export function normalizeString(str: string): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Standard Levenshtein Distance
 */
export function levenshteinDistance(a: string, b: string): number {
  const an = a ? a.length : 0;
  const bn = b ? b.length : 0;
  if (an === 0) return bn;
  if (bn === 0) return an;

  const matrix = Array.from({ length: bn + 1 }, () => new Array(an + 1).fill(0));
  for (let i = 0; i <= an; ++i) matrix[0][i] = i;
  for (let i = 0; i <= bn; ++i) matrix[i][0] = i;

  for (let i = 1; i <= bn; ++i) {
    for (let j = 1; j <= an; ++j) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }
  return matrix[bn][an];
}

/**
 * String similarity ratio (0.0 to 1.0)
 */
export function stringSimilarity(a: string, b: string): number {
  const normA = normalizeString(a);
  const normB = normalizeString(b);
  if (!normA && !normB) return 1;
  if (!normA || !normB) return 0;
  if (normA === normB) return 1;

  const maxLen = Math.max(normA.length, normB.length);
  const dist = levenshteinDistance(normA, normB);
  const levRatio = (maxLen - dist) / maxLen;

  // Token Jaccard similarity (handles word permutations)
  const stopWords = new Set(['le', 'la', 'les', 'de', 'du', 'des', 'un', 'une', 'en', 'et', 'avec', 'sans', 'pour', 'a', 'au']);
  const tokensA = new Set(normA.split(' ').filter(t => t.length > 1 && !stopWords.has(t)));
  const tokensB = new Set(normB.split(' ').filter(t => t.length > 1 && !stopWords.has(t)));

  let intersection = 0;
  for (const t of tokensA) {
    if (tokensB.has(t)) intersection++;
  }
  const union = new Set([...tokensA, ...tokensB]).size;
  const jaccard = union > 0 ? intersection / union : 0;

  // Weighted combo
  return 0.5 * levRatio + 0.5 * jaccard;
}

/**
 * Normalize and compare state/condition
 */
export function areStatesEquivalent(stateA: string, stateB: string): boolean {
  const normA = normalizeString(stateA);
  const normB = normalizeString(stateB);
  if (!normA && !normB) return true;
  if (normA === normB) return true;

  const good = ['bon', 'tres bon', 'tb', 'excellent', 'neuf', 'parfait', 'b'];
  const medium = ['moyen', 'passable', 'correct', 'usage', 'regulier', 'm'];
  const bad = ['mauvais', 'hs', 'hors service', 'deteriore', 'abime', 'defectueux', 'a reformer', 'reforme', 'panne', 'en panne'];

  if (good.includes(normA) && good.includes(normB)) return true;
  if (medium.includes(normA) && medium.includes(normB)) return true;
  if (bad.includes(normA) && bad.includes(normB)) return true;

  return false;
}

/**
 * Detect duplicates inside a single inventory list
 */
export function detectDuplicates(items: InventoryItem[]): Set<string> {
  const duplicateIds = new Set<string>();
  const codeTracker = new Map<string, string[]>();
  const desigTracker = new Map<string, string[]>();

  for (const item of items) {
    // Check code duplicate if code is meaningful
    if (item.code && item.code.trim().length >= 2) {
      const key = `${normalizeString(item.direction)}|${normalizeString(item.bureau)}|${normalizeString(item.code)}`;
      const existing = codeTracker.get(key) || [];
      existing.push(item.id);
      codeTracker.set(key, existing);
    }

    // Check designation duplicate in the exact same room
    if (item.designation && item.designation.trim().length >= 3) {
      const key = `${normalizeString(item.direction)}|${normalizeString(item.bureau)}|${normalizeString(item.designation)}`;
      const existing = desigTracker.get(key) || [];
      existing.push(item.id);
      desigTracker.set(key, existing);
    }
  }

  for (const ids of codeTracker.values()) {
    if (ids.length > 1) {
      ids.forEach(id => duplicateIds.add(id));
    }
  }

  return duplicateIds;
}

/**
 * Main Inventory Reconciliation Engine
 */
export function reconcileInventories(itemsA: InventoryItem[], itemsB: InventoryItem[]): {
  pairs: MatchPair[];
  summary: ReconciliationSummary;
} {
  const duplicatesA = detectDuplicates(itemsA);
  const duplicatesB = detectDuplicates(itemsB);

  const matchedBIds = new Set<string>();
  const matchedAIds = new Set<string>();
  const pairs: MatchPair[] = [];

  // Pass 1: Exact Match by Location + Code
  for (const itemA of itemsA) {
    if (duplicatesA.has(itemA.id)) {
      // Flag as duplicate
      pairs.push({
        id: `pair-dup-a-${itemA.id}`,
        status: 'doublon',
        statusLabel: 'Doublon interne Groupe A',
        itemA,
        confidence: 100,
        matchReason: `Saisie en doublon dans le Groupe A (Code: ${itemA.code || 'sans code'} - Emplacement: ${itemA.bureau || 'N/A'})`
      });
      matchedAIds.add(itemA.id);
      continue;
    }

    const normDirA = normalizeString(itemA.direction);
    const normBurA = normalizeString(itemA.bureau);
    const normCodeA = normalizeString(itemA.code);

    if (normCodeA) {
      // Find candidate in same location with exact code
      const candidateB = itemsB.find(b => 
        !matchedBIds.has(b.id) &&
        !duplicatesB.has(b.id) &&
        normalizeString(b.code) === normCodeA &&
        normalizeString(b.bureau) === normBurA &&
        (normDirA === '' || normalizeString(b.direction) === '' || normalizeString(b.direction) === normDirA)
      );

      if (candidateB) {
        matchedAIds.add(itemA.id);
        matchedBIds.add(candidateB.id);

        const qtyEqual = Number(itemA.quantite) === Number(candidateB.quantite);
        const stateEqual = areStatesEquivalent(itemA.etat, candidateB.etat);
        const qtyDelta = candidateB.quantite - itemA.quantite;

        let status: MatchStatus = 'commun_conforme';
        let statusLabel = 'Commun conforme';
        let reason = 'Concordance exacte sur le code d\'inventaire et l\'emplacement';

        if (!qtyEqual && !stateEqual) {
          status = 'ecart_quantite';
          statusLabel = 'Écart de quantité et d\'état';
          reason = `Écart constaté : Quantité A=${itemA.quantite} vs B=${candidateB.quantite} (Delta: ${qtyDelta > 0 ? '+' : ''}${qtyDelta}), État A="${itemA.etat}" vs B="${candidateB.etat}"`;
        } else if (!qtyEqual) {
          status = 'ecart_quantite';
          statusLabel = 'Écart de quantité';
          reason = `Écart de quantité : A=${itemA.quantite} vs B=${candidateB.quantite} (Delta: ${qtyDelta > 0 ? '+' : ''}${qtyDelta})`;
        } else if (!stateEqual) {
          status = 'ecart_etat';
          statusLabel = 'Écart d\'état ou de statut';
          reason = `Divergence d'état physique : A="${itemA.etat}" vs B="${candidateB.etat}"`;
        }

        pairs.push({
          id: `pair-${itemA.id}-${candidateB.id}`,
          status,
          statusLabel,
          itemA,
          itemB: candidateB,
          confidence: 100,
          matchReason: reason,
          quantiteDelta: qtyDelta
        });
      }
    }
  }

  // Pass 2: Same Location, Match by Designation (when code is absent or divergent)
  for (const itemA of itemsA) {
    if (matchedAIds.has(itemA.id)) continue;

    const normDirA = normalizeString(itemA.direction);
    const normBurA = normalizeString(itemA.bureau);

    // Candidates in same room
    const candidates = itemsB.filter(b => 
      !matchedBIds.has(b.id) &&
      !duplicatesB.has(b.id) &&
      normalizeString(b.bureau) === normBurA &&
      (normDirA === '' || normalizeString(b.direction) === '' || normalizeString(b.direction) === normDirA)
    );

    let bestCandidate: InventoryItem | null = null;
    let highestSim = 0;

    for (const cand of candidates) {
      const sim = stringSimilarity(itemA.designation, cand.designation);
      if (sim > highestSim) {
        highestSim = sim;
        bestCandidate = cand;
      }
    }

    // High confidence similarity threshold
    if (bestCandidate && highestSim >= 0.85) {
      matchedAIds.add(itemA.id);
      matchedBIds.add(bestCandidate.id);

      const qtyEqual = Number(itemA.quantite) === Number(bestCandidate.quantite);
      const stateEqual = areStatesEquivalent(itemA.etat, bestCandidate.etat);
      const qtyDelta = bestCandidate.quantite - itemA.quantite;

      let status: MatchStatus = 'commun_conforme';
      let statusLabel = 'Commun conforme (par désignation)';
      let reason = `Correspondance textuelle forte (${Math.round(highestSim * 100)}%) dans le même bureau`;

      if (!qtyEqual) {
        status = 'ecart_quantite';
        statusLabel = 'Écart de quantité';
        reason = `Apparié par désignation (${Math.round(highestSim * 100)}%), Écart qté: A=${itemA.quantite} vs B=${bestCandidate.quantite}`;
      } else if (!stateEqual) {
        status = 'ecart_etat';
        statusLabel = 'Écart d\'état';
        reason = `Apparié par désignation (${Math.round(highestSim * 100)}%), Divergence état: A="${itemA.etat}" vs B="${bestCandidate.etat}"`;
      }

      pairs.push({
        id: `pair-${itemA.id}-${bestCandidate.id}`,
        status,
        statusLabel,
        itemA,
        itemB: bestCandidate,
        confidence: Math.round(highestSim * 100),
        matchReason: reason,
        quantiteDelta: qtyDelta
      });
    } else if (bestCandidate && highestSim >= 0.65) {
      // Partial match: Do not pair arbitrarily! Flag as "À vérifier"
      matchedAIds.add(itemA.id);
      matchedBIds.add(bestCandidate.id);

      pairs.push({
        id: `pair-check-${itemA.id}-${bestCandidate.id}`,
        status: 'a_verifier',
        statusLabel: 'À vérifier (correspondance incertaine)',
        itemA,
        itemB: bestCandidate,
        confidence: Math.round(highestSim * 100),
        matchReason: `Similarité modérée (${Math.round(highestSim * 100)}%) : "${itemA.designation}" vs "${bestCandidate.designation}". Validation manuelle requise.`,
        quantiteDelta: bestCandidate.quantite - itemA.quantite
      });
    }
  }

  // Pass 3: Cross-Location Code Search (Detect items physically moved to another room)
  for (const itemA of itemsA) {
    if (matchedAIds.has(itemA.id)) continue;
    const normCodeA = normalizeString(itemA.code);

    if (normCodeA && normCodeA.length >= 3) {
      const movedCandidate = itemsB.find(b => 
        !matchedBIds.has(b.id) &&
        !duplicatesB.has(b.id) &&
        normalizeString(b.code) === normCodeA
      );

      if (movedCandidate) {
        matchedAIds.add(itemA.id);
        matchedBIds.add(movedCandidate.id);

        pairs.push({
          id: `pair-moved-${itemA.id}-${movedCandidate.id}`,
          status: 'a_verifier',
          statusLabel: 'À vérifier (Déplacement de bureau)',
          itemA,
          itemB: movedCandidate,
          confidence: 90,
          isLocationMismatch: true,
          matchReason: `Code identique trouvé mais emplacement déplacé : Bureau A = "${itemA.bureau || 'Non renseigné'}" -> Bureau B = "${movedCandidate.bureau || 'Non renseigné'}"`,
          quantiteDelta: movedCandidate.quantite - itemA.quantite
        });
        continue;
      }
    }
  }

  // Pass 4: Unmatched items in A are "Absent du Groupe B" (Missing in B)
  for (const itemA of itemsA) {
    if (!matchedAIds.has(itemA.id)) {
      pairs.push({
        id: `pair-absent-b-${itemA.id}`,
        status: 'absent_b',
        statusLabel: 'Absent du Groupe B (Déficit / Non retrouvé)',
        itemA,
        confidence: 100,
        matchReason: `Bien recensé dans le Groupe A (Code: ${itemA.code || 'N/A'}, Emplacement: ${itemA.bureau || 'N/A'}) mais introuvable lors de l'inventaire B`,
        quantiteDelta: -itemA.quantite
      });
    }
  }

  // Pass 5: Handle duplicates in B
  for (const itemB of itemsB) {
    if (duplicatesB.has(itemB.id)) {
      pairs.push({
        id: `pair-dup-b-${itemB.id}`,
        status: 'doublon',
        statusLabel: 'Doublon interne Groupe B',
        itemB,
        confidence: 100,
        matchReason: `Saisie en doublon dans le Groupe B (Code: ${itemB.code || 'sans code'} - Emplacement: ${itemB.bureau || 'N/A'})`
      });
      matchedBIds.add(itemB.id);
    }
  }

  // Pass 6: Unmatched items in B are "Absent du Groupe A" (Surplus / Non inscrit dans A)
  for (const itemB of itemsB) {
    if (!matchedBIds.has(itemB.id)) {
      pairs.push({
        id: `pair-absent-a-${itemB.id}`,
        status: 'absent_a',
        statusLabel: 'Absent du Groupe A (Surplus physique)',
        itemB,
        confidence: 100,
        matchReason: `Bien physique constaté dans le Groupe B (Bureau: ${itemB.bureau || 'N/A'}, Code: ${itemB.code || 'N/A'}) non répertorié dans le référentiel A`,
        quantiteDelta: itemB.quantite
      });
    }
  }

  // Compute Comprehensive Summary & Metrics
  const totalItemsA = itemsA.length;
  const totalQuantiteA = itemsA.reduce((sum, item) => sum + (Number(item.quantite) || 0), 0);
  const totalItemsB = itemsB.length;
  const totalQuantiteB = itemsB.reduce((sum, item) => sum + (Number(item.quantite) || 0), 0);

  const conformeCount = pairs.filter(p => p.status === 'commun_conforme').length;
  const ecartQuantiteCount = pairs.filter(p => p.status === 'ecart_quantite').length;
  const ecartEtatCount = pairs.filter(p => p.status === 'ecart_etat').length;
  const absentACount = pairs.filter(p => p.status === 'absent_a').length;
  const absentBCount = pairs.filter(p => p.status === 'absent_b').length;
  const doublonCount = pairs.filter(p => p.status === 'doublon').length;
  const aVerifierCount = pairs.filter(p => p.status === 'a_verifier').length;

  const totalUniqueAssets = pairs.length;

  // Calcul du taux de concordance (Audit Standard):
  // Concordance stricte = Biens conformes / Total des lignes de rapprochement uniques
  const tauxConcordance = totalUniqueAssets > 0
    ? Math.round((conformeCount / totalUniqueAssets) * 1000) / 10
    : 0;

  // Taux d'identification (Biens A retrouvés dans B, quelle que soit la variation):
  const foundACount = pairs.filter(p => p.itemA && p.itemB).length;
  const tauxIdentification = totalItemsA > 0
    ? Math.round((foundACount / totalItemsA) * 1000) / 10
    : 0;

  // Probable Causes derivation
  const causesProbables: ProbableCause[] = [];

  const movedCount = pairs.filter(p => p.isLocationMismatch).length;
  if (movedCount > 0) {
    causesProbables.push({
      title: 'Mouvements internes non formalisés',
      description: `${movedCount} bien(s) ont été physiquement déplacés d'un bureau ou d'une direction à une autre sans établissement de bon de transfert ou mise à jour du registre.`,
      count: movedCount,
      category: 'logistique'
    });
  }

  if (ecartQuantiteCount > 0) {
    causesProbables.push({
      title: 'Écarts quantitatifs (Pertes, consommations ou sous-comptage)',
      description: `${ecartQuantiteCount} référence(s) présentent une divergence de quantité physique constatée. Causes probables : défaut de comptage unitaire, casse non déclarée ou sortie d'immobilisation non actée.`,
      count: ecartQuantiteCount,
      category: 'patrimoine'
    });
  }

  if (ecartEtatCount > 0) {
    causesProbables.push({
      title: 'Évolution de l\'état d\'usage / Vétusté non réévaluée',
      description: `${ecartEtatCount} équipement(s) divergent sur l'état physique (notamment passage à "Hors service" ou "En panne"), indiquant un manque de traçabilité des pannes et réparations.`,
      count: ecartEtatCount,
      category: 'degradation'
    });
  }

  if (absentACount > 0) {
    causesProbables.push({
      title: 'Acquisitions ou dotations non intégrées au référentiel A',
      description: `${absentACount} bien(s) présents physiquement lors du recensement B n'ont aucune correspondance dans le Groupe A (achats directs de service, matériels prêtés ou non enregistrés en comptabilité).`,
      count: absentACount,
      category: 'conformite'
    });
  }

  if (absentBCount > 0) {
    causesProbables.push({
      title: 'Biens répertoriés non localisés (Risque de perte ou mise au rebut)',
      description: `${absentBCount} bien(s) du Groupe A sont absents de l'inventaire physique B. Risque d'égarement, de vol ou de mise au rebut sans procès-verbal de réforme.`,
      count: absentBCount,
      category: 'patrimoine'
    });
  }

  if (doublonCount > 0) {
    causesProbables.push({
      title: 'Anomalies de saisie ou ré-étiquetage multiple',
      description: `${doublonCount} doublon(s) détecté(s) au sein d'un même fichier. Risque d'étiquette scannée deux fois ou numéro d'inventaire attribué à deux biens distincts.`,
      count: doublonCount,
      category: 'saisie'
    });
  }

  // Strategic Audit Recommendations
  const recommandations: string[] = [
    "Diligenter une contre-visite contradictoire sur les éléments classés « À vérifier » et les biens absents avec les responsables de bureaux concernés.",
    "Régulariser les transferts physiques d'équipements par l'émission systématique de « Bons de Mouvement Interne » visés par la Direction.",
    "Procéder à la commission de réforme pour les matériels constatés « Hors service » ou irrécupérables afin d'apurer l'actif comptable.",
    "Lancer une opération de ré-étiquetage unifié (codes-barres ou QR codes indécollables) pour tous les biens sans code ou en doublon.",
    "Harmoniser la nomenclature des désignations et instaurer un protocole d'inventaire tournant trimestriel par direction."
  ];

  const methodologieCalcul = `Taux de concordance strict calculé selon la formule : (Nombre de biens rigoureusement conformes en quantité, état et emplacement / Nombre total de références uniques rapprochées) × 100. Soit : (${conformeCount} / ${totalUniqueAssets}) × 100 = ${tauxConcordance}%. Le taux d'identification globale est de ${tauxIdentification}% (${foundACount} biens du Groupe A localisés dans le Groupe B).`;

  return {
    pairs,
    summary: {
      totalItemsA,
      totalQuantiteA,
      totalItemsB,
      totalQuantiteB,
      totalUniqueAssets,
      conformeCount,
      ecartQuantiteCount,
      ecartEtatCount,
      absentACount,
      absentBCount,
      doublonCount,
      aVerifierCount,
      tauxConcordance,
      tauxIdentification,
      methodologieCalcul,
      causesProbables,
      recommandations
    }
  };
}
