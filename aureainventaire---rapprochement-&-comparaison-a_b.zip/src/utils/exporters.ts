import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Document, Packer, Paragraph, Table, TableRow, TableCell, TextRun, HeadingLevel, WidthType, AlignmentType, BorderStyle } from 'docx';
import { InventoryItem, MatchPair, ReconciliationSummary, CommissionInfo } from '../types/inventory';

/**
 * Trigger file download in browser
 */
function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Format status for human export
 */
function getStatusLabelExport(status: string): string {
  switch (status) {
    case 'commun_conforme': return 'Commun conforme';
    case 'ecart_quantite': return 'Écart de quantité';
    case 'ecart_etat': return 'Écart d\'état / statut';
    case 'absent_a': return 'Absent du Groupe A (Surplus)';
    case 'absent_b': return 'Absent du Groupe B (Déficit)';
    case 'doublon': return 'Doublon interne';
    case 'a_verifier': return 'À vérifier';
    default: return status;
  }
}

// ==========================================
// 1. EXCEL EXPORTS (.xlsx)
// ==========================================

export function exportReconciliationToExcel(
  pairs: MatchPair[],
  summary: ReconciliationSummary,
  itemsA: InventoryItem[],
  itemsB: InventoryItem[],
  commissionA?: CommissionInfo,
  commissionB?: CommissionInfo,
  title = 'Rapprochement_Inventaires_A_B'
) {
  const wb = XLSX.utils.book_new();

  // Sheet 1: Synthèse
  const syntheseData = [
    ['RAPPORT DE RAPPROCHEMENT ET COMPARAISON DES INVENTAIRES A/B'],
    ['Généré le', new Date().toLocaleString('fr-FR')],
    [''],
    ['INDICATEURS CLÉS DE CONCORDANCE', 'VALEUR', 'UNITÉ / DÉTAIL'],
    ['Total Références Groupe A', summary.totalItemsA, 'Lignes d\'inventaire'],
    ['Quantité Totale Recensée Groupe A', summary.totalQuantiteA, 'Unités physiques'],
    ['Total Références Groupe B', summary.totalItemsB, 'Lignes d\'inventaire'],
    ['Quantité Totale Recensée Groupe B', summary.totalQuantiteB, 'Unités physiques'],
    ['Total Références Uniques Rapprochées', summary.totalUniqueAssets, 'Articles distincts'],
    [''],
    ['TAUX DE CONCORDANCE STRICT', `${summary.tauxConcordance}%`, 'Critère : Quantité + État + Emplacement identiques'],
    ['TAUX D\'IDENTIFICATION GLOBALE', `${summary.tauxIdentification}%`, 'Critère : Biens de A retrouvés dans B'],
    ['Méthodologie appliquée', summary.methodologieCalcul],
    [''],
    ['DÉCOMPTE PAR STATUT D\'ÉCART', 'VOLUME', 'POURCENTAGE'],
    ['Biens Communs Conformes', summary.conformeCount, `${Math.round((summary.conformeCount / (summary.totalUniqueAssets || 1)) * 100)}%`],
    ['Écarts de Quantité', summary.ecartQuantiteCount, `${Math.round((summary.ecartQuantiteCount / (summary.totalUniqueAssets || 1)) * 100)}%`],
    ['Écarts d\'État / Statut', summary.ecartEtatCount, `${Math.round((summary.ecartEtatCount / (summary.totalUniqueAssets || 1)) * 100)}%`],
    ['Absents du Groupe B (Déficit / Non retrouvés)', summary.absentBCount, `${Math.round((summary.absentBCount / (summary.totalUniqueAssets || 1)) * 100)}%`],
    ['Absents du Groupe A (Surplus physique)', summary.absentACount, `${Math.round((summary.absentACount / (summary.totalUniqueAssets || 1)) * 100)}%`],
    ['Doublons de saisie internes', summary.doublonCount, `${Math.round((summary.doublonCount / (summary.totalUniqueAssets || 1)) * 100)}%`],
    ['À vérifier (Correspondances incertaines)', summary.aVerifierCount, `${Math.round((summary.aVerifierCount / (summary.totalUniqueAssets || 1)) * 100)}%`],
    [''],
    ['CAUSES PROBABLES DÉTECTÉES', 'NOMBRE DE CAS', 'EXPLICATION D\'AUDIT']
  ];

  summary.causesProbables.forEach(c => {
    syntheseData.push([c.title, c.count.toString(), c.description]);
  });

  syntheseData.push(['']);
  syntheseData.push(['RECOMMANDATIONS D\'AUDIT PATRIMONIAL']);
  summary.recommandations.forEach((rec, idx) => {
    syntheseData.push([`Recommandation ${idx + 1}`, rec]);
  });

  const wsSynthese = XLSX.utils.aoa_to_sheet(syntheseData);
  XLSX.utils.book_append_sheet(wb, wsSynthese, 'Synthèse');

  // Sheet 2: Matrice de Rapprochement
  const matrixHeaders = [
    'Statut Rapprochement',
    'Direction A',
    'Bureau A',
    'Code Inventaire A',
    'Désignation A',
    'Qté A',
    'État A',
    'Direction B',
    'Bureau B',
    'Code Inventaire B',
    'Désignation B',
    'Qté B',
    'État B',
    'Delta Qté (B - A)',
    'Indice Confiance',
    'Motif / Analyse de l\'écart',
    'Observations / Détails'
  ];

  const matrixRows = pairs.map(p => [
    getStatusLabelExport(p.status),
    p.itemA?.direction || '',
    p.itemA?.bureau || '',
    p.itemA?.code || '',
    p.itemA?.designation || '',
    p.itemA?.quantite ?? '',
    p.itemA?.etat || '',
    p.itemB?.direction || '',
    p.itemB?.bureau || '',
    p.itemB?.code || '',
    p.itemB?.designation || '',
    p.itemB?.quantite ?? '',
    p.itemB?.etat || '',
    p.quantiteDelta !== undefined ? p.quantiteDelta : '',
    `${p.confidence}%`,
    p.matchReason || '',
    p.itemA?.observations || p.itemB?.observations || ''
  ]);

  const wsMatrix = XLSX.utils.aoa_to_sheet([matrixHeaders, ...matrixRows]);
  XLSX.utils.book_append_sheet(wb, wsMatrix, 'Matrice Rapprochement');

  // Sheet 3: Groupe A
  const wsA = XLSX.utils.json_to_sheet(itemsA.map(i => ({
    'Direction': i.direction,
    'Bureau': i.bureau,
    'Bloc / Bâtiment': i.bloc,
    'Code Inventaire': i.code,
    'Désignation': i.designation,
    'Quantité': i.quantite,
    'État': i.etat,
    'Date': i.date,
    'Observations': i.observations
  })));
  XLSX.utils.book_append_sheet(wb, wsA, 'Groupe A');

  // Sheet 4: Groupe B
  const wsB = XLSX.utils.json_to_sheet(itemsB.map(i => ({
    'Direction': i.direction,
    'Bureau': i.bureau,
    'Bloc / Bâtiment': i.bloc,
    'Code Inventaire': i.code,
    'Désignation': i.designation,
    'Quantité': i.quantite,
    'État': i.etat,
    'Date': i.date,
    'Observations': i.observations
  })));
  XLSX.utils.book_append_sheet(wb, wsB, 'Groupe B');

  // Sheet 5: Commissions (if detected)
  const commData = [
    ['COMMISSIONS D\'INVENTAIRE ET SIGNATAIRES (NON COMPARÉS)'],
    [''],
    ['GROUPE A :'],
    ['Président :', commissionA?.president || 'Non spécifié'],
    ['Membres :', commissionA?.membres?.join(', ') || 'Non spécifié'],
    ['Date PV :', commissionA?.datePV || 'Non spécifié'],
    [''],
    ['GROUPE B :'],
    ['Président :', commissionB?.president || 'Non spécifié'],
    ['Membres :', commissionB?.membres?.join(', ') || 'Non spécifié'],
    ['Date PV :', commissionB?.datePV || 'Non spécifié']
  ];
  const wsComm = XLSX.utils.aoa_to_sheet(commData);
  XLSX.utils.book_append_sheet(wb, wsComm, 'Commissions');

  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  downloadBlob(blob, `${title}_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

export function exportSingleGroupToExcel(items: InventoryItem[], groupName: 'Groupe_A' | 'Groupe_B') {
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(items.map(i => ({
    'Direction': i.direction,
    'Bureau / Emplacement': i.bureau,
    'Bloc': i.bloc,
    'Code d\'inventaire': i.code,
    'Désignation du bien': i.designation,
    'Quantité': i.quantite,
    'État / Statut': i.etat,
    'Date': i.date,
    'Observations': i.observations
  })));
  XLSX.utils.book_append_sheet(wb, ws, groupName);
  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  downloadBlob(blob, `Inventaire_${groupName}_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

// ==========================================
// 2. WORD EXPORTS (.docx)
// ==========================================

export async function exportReconciliationToWord(
  pairs: MatchPair[],
  summary: ReconciliationSummary,
  commissionA?: CommissionInfo,
  commissionB?: CommissionInfo,
  fileName = 'Proces_Verbal_Rapprochement_Inventaires.docx'
) {
  const tableRows: TableRow[] = [
    new TableRow({
      tableHeader: true,
      children: [
        new TableCell({ children: [new Paragraph({ text: 'Statut', alignment: AlignmentType.CENTER })], width: { size: 18, type: WidthType.PERCENTAGE } }),
        new TableCell({ children: [new Paragraph({ text: 'Emplacement', alignment: AlignmentType.CENTER })], width: { size: 18, type: WidthType.PERCENTAGE } }),
        new TableCell({ children: [new Paragraph({ text: 'Groupe A (Code & Désignation)', alignment: AlignmentType.CENTER })], width: { size: 28, type: WidthType.PERCENTAGE } }),
        new TableCell({ children: [new Paragraph({ text: 'Groupe B (Code & Désignation)', alignment: AlignmentType.CENTER })], width: { size: 28, type: WidthType.PERCENTAGE } }),
        new TableCell({ children: [new Paragraph({ text: 'Écart Qté', alignment: AlignmentType.CENTER })], width: { size: 8, type: WidthType.PERCENTAGE } }),
      ]
    })
  ];

  pairs.forEach(p => {
    const loc = p.itemA?.bureau || p.itemB?.bureau || p.itemA?.direction || 'N/A';
    const descA = p.itemA ? `[${p.itemA.code || 'S/C'}] ${p.itemA.designation} (Qté: ${p.itemA.quantite}, État: ${p.itemA.etat})` : '— Absent —';
    const descB = p.itemB ? `[${p.itemB.code || 'S/C'}] ${p.itemB.designation} (Qté: ${p.itemB.quantite}, État: ${p.itemB.etat})` : '— Absent —';
    const delta = p.quantiteDelta !== undefined ? (p.quantiteDelta > 0 ? `+${p.quantiteDelta}` : `${p.quantiteDelta}`) : '0';

    tableRows.push(
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph(getStatusLabelExport(p.status))] }),
          new TableCell({ children: [new Paragraph(loc)] }),
          new TableCell({ children: [new Paragraph(descA)] }),
          new TableCell({ children: [new Paragraph(descB)] }),
          new TableCell({ children: [new Paragraph({ text: delta, alignment: AlignmentType.CENTER })] }),
        ]
      })
    );
  });

  const doc = new Document({
    sections: [
      {
        properties: {},
        children: [
          new Paragraph({
            text: 'PROCÈS-VERBAL DE RAPPROCHEMENT ET DE COMPARAISON DES INVENTAIRES',
            heading: HeadingLevel.HEADING_1,
            alignment: AlignmentType.CENTER
          }),
          new Paragraph({
            text: `Document d'audit contradictoire - Généré le ${new Date().toLocaleDateString('fr-FR')}`,
            alignment: AlignmentType.CENTER
          }),
          new Paragraph({ text: '' }),

          new Paragraph({ text: '1. Synthèse Exécutive et Taux de Concordance', heading: HeadingLevel.HEADING_2 }),
          new Paragraph({
            children: [
              new TextRun({ text: `• Taux de concordance strict : `, bold: true }),
              new TextRun({ text: `${summary.tauxConcordance}%`, bold: true, color: 'B8860B' }),
              new TextRun({ text: ` (Biens rigoureusement conformes en emplacement, code, quantité et état).\n` }),
              new TextRun({ text: `• Taux d'identification global : `, bold: true }),
              new TextRun({ text: `${summary.tauxIdentification}%\n` }),
              new TextRun({ text: `• Total articles Groupe A : ${summary.totalItemsA} (${summary.totalQuantiteA} unités physiques)\n` }),
              new TextRun({ text: `• Total articles Groupe B : ${summary.totalItemsB} (${summary.totalQuantiteB} unités physiques)\n` }),
              new TextRun({ text: `• Biens conformes : ${summary.conformeCount} | Écarts quantité : ${summary.ecartQuantiteCount} | Écarts état : ${summary.ecartEtatCount}\n` }),
              new TextRun({ text: `• Biens manquants dans B : ${summary.absentBCount} | Biens en surplus (non inscrits dans A) : ${summary.absentACount} | Doublons : ${summary.doublonCount}\n` })
            ]
          }),
          new Paragraph({ text: '' }),

          new Paragraph({ text: '2. Méthodologie et Formule de Calcul', heading: HeadingLevel.HEADING_2 }),
          new Paragraph({ text: summary.methodologieCalcul }),
          new Paragraph({ text: '' }),

          new Paragraph({ text: '3. Analyse des Causes Probables et Recommandations', heading: HeadingLevel.HEADING_2 }),
          ...summary.causesProbables.map(c => new Paragraph({
            children: [
              new TextRun({ text: `• ${c.title} (${c.count} cas) : `, bold: true }),
              new TextRun({ text: c.description })
            ]
          })),
          new Paragraph({ text: '' }),
          new Paragraph({
            children: [
              new TextRun({ text: 'Recommandations formulées par l\'audit :', bold: true })
            ]
          }),
          ...summary.recommandations.map(r => new Paragraph({ text: `  → ${r}` })),
          new Paragraph({ text: '' }),

          new Paragraph({ text: '4. Matrice Détaillée de Concordance et Écarts', heading: HeadingLevel.HEADING_2 }),
          new Table({
            rows: tableRows,
            width: { size: 100, type: WidthType.PERCENTAGE }
          }),
          new Paragraph({ text: '' }),

          new Paragraph({ text: '5. Visas et Commissions d\'Inventaire', heading: HeadingLevel.HEADING_2 }),
          new Paragraph({
            text: `Commission A : Président : ${commissionA?.president || 'Non renseigné'} | Membres : ${commissionA?.membres?.join(', ') || 'Non renseigné'}`
          }),
          new Paragraph({
            text: `Commission B : Président : ${commissionB?.president || 'Non renseigné'} | Membres : ${commissionB?.membres?.join(', ') || 'Non renseigné'}`
          }),
          new Paragraph({ text: '' }),
          new Paragraph({
            text: 'Fait pour valoir ce que de droit.\nSignatures des rapporteurs d\'inventaire et contrôleurs de gestion :',
            alignment: AlignmentType.RIGHT
          })
        ]
      }
    ]
  });

  const blob = await Packer.toBlob(doc);
  downloadBlob(blob, fileName);
}

// ==========================================
// 3. PDF EXPORTS (.pdf)
// ==========================================

export function exportReconciliationToPdf(
  pairs: MatchPair[],
  summary: ReconciliationSummary,
  commissionA?: CommissionInfo,
  commissionB?: CommissionInfo,
  fileName = 'Rapport_Rapprochement_Inventaires_AB.pdf'
) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

  // Header banner
  doc.setFillColor(8, 10, 15);
  doc.rect(0, 0, 297, 24, 'F');

  doc.setTextColor(212, 175, 55); // Gold
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('AUREAINVENTAIRE — RAPPORT DE RAPPROCHEMENT DES INVENTAIRES A/B', 14, 12);

  doc.setTextColor(200, 200, 200);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Rapport d'audit officiel généré hors-ligne le ${new Date().toLocaleDateString('fr-FR')} | Confidentiel`, 14, 19);

  // Summary box
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(14, 28, 269, 32, 2, 2, 'F');
  doc.setDrawColor(212, 175, 55);
  doc.setLineWidth(0.4);
  doc.roundedRect(14, 28, 269, 32, 2, 2, 'D');

  doc.setTextColor(17, 24, 39);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(`Taux de Concordance Strict : ${summary.tauxConcordance}%`, 20, 36);
  doc.text(`Taux d'Identification Global : ${summary.tauxIdentification}%`, 110, 36);
  doc.text(`Total Rapproché : ${summary.totalUniqueAssets} références`, 200, 36);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`• Groupe A : ${summary.totalItemsA} biens (${summary.totalQuantiteA} unités) | Groupe B : ${summary.totalItemsB} biens (${summary.totalQuantiteB} unités)`, 20, 43);
  doc.text(`• Conformes : ${summary.conformeCount} | Écarts qté : ${summary.ecartQuantiteCount} | Écarts état : ${summary.ecartEtatCount} | Manquants B : ${summary.absentBCount} | Surplus B : ${summary.absentACount} | Doublons : ${summary.doublonCount}`, 20, 49);
  doc.text(`• Méthode : ${summary.methodologieCalcul.slice(0, 150)}...`, 20, 55);

  // Table rows
  const tableData = pairs.map(p => [
    getStatusLabelExport(p.status),
    p.itemA?.direction || p.itemB?.direction || '—',
    p.itemA?.bureau || p.itemB?.bureau || '—',
    p.itemA?.code || '—',
    p.itemA?.designation || '—',
    p.itemA?.quantite?.toString() || '—',
    p.itemA?.etat || '—',
    p.itemB?.code || '—',
    p.itemB?.designation || '—',
    p.itemB?.quantite?.toString() || '—',
    p.itemB?.etat || '—',
    p.quantiteDelta !== undefined ? (p.quantiteDelta > 0 ? `+${p.quantiteDelta}` : `${p.quantiteDelta}`) : '—',
    p.matchReason || ''
  ]);

  autoTable(doc, {
    startY: 64,
    head: [[
      'Statut', 'Direction', 'Bureau', 'Code A', 'Désignation A', 'Qté A', 'État A',
      'Code B', 'Désignation B', 'Qté B', 'État B', 'Delta', 'Motif'
    ]],
    body: tableData,
    styles: { fontSize: 7, cellPadding: 2, overflow: 'linebreak' },
    headStyles: { fillColor: [17, 24, 39], textColor: [212, 175, 55], fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    columnStyles: {
      0: { cellWidth: 26 },
      4: { cellWidth: 40 },
      8: { cellWidth: 40 },
      12: { cellWidth: 45 }
    },
    didDrawPage: (data) => {
      // Footer page numbering
      const pageNumber = doc.getNumberOfPages();
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text(
        `Page ${data.pageNumber} sur ${pageNumber} — AureaInventaire Traitement Local Hors-Ligne`,
        14,
        202
      );
    }
  });

  doc.save(fileName);
}
