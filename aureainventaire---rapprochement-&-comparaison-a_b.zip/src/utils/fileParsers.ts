import * as XLSX from 'xlsx';
import mammoth from 'mammoth';
import * as pdfjsLib from 'pdfjs-dist';
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';
import { createWorker } from 'tesseract.js';
import { InventoryItem, CommissionInfo } from '../types/inventory';

// Configure offline worker for PDF.js
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

export interface ParseResult {
  items: InventoryItem[];
  commission: CommissionInfo;
  rawText: string;
  isScanned?: boolean;
  warnings: string[];
}

// Normalized column identifiers
const COLUMN_ALIASES = {
  direction: ['direction', 'departement', 'service', 'division', 'entite', 'direction generale', 'sous-direction', 'pole'],
  bureau: ['bureau', 'no bureau', 'num bureau', 'local', 'salle', 'piece', 'porte', 'emplacement', 'chambre'],
  code: ['code', 'code inventaire', 'num inventaire', 'n inventaire', 'no inventaire', 'immatriculation', 'code-barre', 'code barre', 'ref', 'reference', 'tag', 'id', 'num'],
  designation: ['designation', 'description', 'libelle', 'nom du bien', 'article', 'materiel', 'equipement', 'nom', 'intitule'],
  quantite: ['quantite', 'qte', 'qte physique', 'qte constatee', 'nombre', 'nbre', 'qte inventoriee', 'total'],
  etat: ['etat', 'statut', 'condition', 'etat physique', 'etat du bien', 'situation'],
  date: ['date', 'date inventaire', 'date acquisition', 'date mise en service', 'date recensement'],
  bloc: ['bloc', 'batiment', 'etage', 'aile', 'pavillon', 'zone', 'niveau'],
  observations: ['observations', 'remarques', 'note', 'commentaires', 'obs', 'no serie', 'serie', 'detail']
};

/**
 * Clean and normalize header strings for fuzzy matching
 */
function normalizeHeader(str: string): string {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, ' ')
    .trim();
}

/**
 * Check if a text line indicates a commission section or members
 */
export function isCommissionLine(line: string): boolean {
  const norm = normalizeHeader(line);
  const patterns = [
    'commission d inventaire',
    'commission de recollement',
    'membres de la commission',
    'president de la commission',
    'president',
    'vice president',
    'rapporteur',
    'emargement',
    'signatures des membres',
    'vise par',
    'visa du president',
    'proces verbal d inventaire',
    'fait a',
    'lu et approuve',
    'cachet et signature'
  ];
  return patterns.some(p => norm.includes(p));
}

/**
 * Extract Commission details (President, Membres, Date, etc.)
 */
export function extractCommissionInfo(lines: string[]): CommissionInfo {
  const info: CommissionInfo = {
    detected: false,
    membres: [],
    rawTextLines: []
  };

  let inCommissionBlock = false;

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;
    const norm = normalizeHeader(line);

    if (isCommissionLine(line)) {
      info.detected = true;
      inCommissionBlock = true;
      info.rawTextLines.push(line);

      // Check president
      if (norm.includes('president') && !norm.includes('vice')) {
        const parts = line.split(/[:\-]/);
        if (parts.length > 1) {
          info.president = parts.slice(1).join(' ').trim();
        } else {
          info.president = line;
        }
      } else if (norm.includes('membre') || norm.includes('rapporteur')) {
        const parts = line.split(/[:\-]/);
        const name = parts.length > 1 ? parts.slice(1).join(' ').trim() : line;
        if (name && !info.membres.includes(name)) {
          info.membres.push(name);
        }
      } else if (norm.includes('fait a') || norm.includes('date :')) {
        info.datePV = line;
      }
    } else if (inCommissionBlock) {
      // If we are in a signature / member footer
      if (line.length < 80 && (norm.includes('m.') || norm.includes('mme') || norm.includes('monsieur') || norm.includes('madame') || norm.includes('dr'))) {
        info.membres.push(line);
        info.rawTextLines.push(line);
      }
    }
  }

  return info;
}

/**
 * Parse an Excel / CSV file
 */
export async function parseExcelFile(file: File): Promise<ParseResult> {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });
  const warnings: string[] = [];
  const allLines: string[] = [];
  const items: InventoryItem[] = [];

  let currentDirection = '';
  let currentBureau = '';
  let currentBloc = '';

  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    // Convert to 2D array of rows
    const rows = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1, defval: '' });

    if (!rows || rows.length === 0) continue;

    let headerMap: { [key in keyof typeof COLUMN_ALIASES]?: number } = {};
    let headerRowIndex = -1;

    // Scan the first 25 rows to identify column headers
    for (let r = 0; r < Math.min(rows.length, 25); r++) {
      const row = rows[r];
      if (!Array.isArray(row)) continue;

      const candidateMap: { [key in keyof typeof COLUMN_ALIASES]?: number } = {};
      let matchCount = 0;

      row.forEach((cell, colIdx) => {
        if (!cell) return;
        const cellNorm = normalizeHeader(String(cell));
        for (const [field, aliases] of Object.entries(COLUMN_ALIASES) as [keyof typeof COLUMN_ALIASES, string[]][]) {
          if (aliases.some(alias => cellNorm === alias || cellNorm.startsWith(alias) || cellNorm.endsWith(alias))) {
            if (candidateMap[field] === undefined) {
              candidateMap[field] = colIdx;
              matchCount++;
            }
          }
        }
      });

      // If we identified designation or code, or at least 2 key columns, this is the header row
      if (matchCount >= 2 || candidateMap.designation !== undefined || (candidateMap.code !== undefined && candidateMap.quantite !== undefined)) {
        headerMap = candidateMap;
        headerRowIndex = r;
        break;
      }
    }

    // Process rows
    for (let r = 0; r < rows.length; r++) {
      const row = rows[r];
      if (!Array.isArray(row) || row.length === 0) continue;

      const rowText = row.map(c => String(c || '').trim()).filter(Boolean).join(' ');
      if (!rowText) continue;
      allLines.push(rowText);

      // Check if commission section
      if (isCommissionLine(rowText)) {
        continue;
      }

      // Check for hierarchical header (e.g. single cell spanning or prefix "Direction:" / "Bureau:")
      const firstCell = String(row[0] || '').trim();
      const firstCellNorm = normalizeHeader(firstCell);
      const isHeaderRow = r === headerRowIndex;

      if (!isHeaderRow) {
        // Detect section title for Direction
        if (firstCellNorm.startsWith('direction') || firstCellNorm.startsWith('departement') || (row.filter(Boolean).length <= 2 && /^(direction|departement|service|pole)/i.test(firstCell))) {
          const val = firstCell.replace(/^(direction|departement|service|pole)\s*[:\-]?\s*/i, '').trim();
          if (val) currentDirection = val;
          continue;
        }

        // Detect section title for Bureau / Salle
        if (firstCellNorm.startsWith('bureau') || firstCellNorm.startsWith('salle') || firstCellNorm.startsWith('local') || (row.filter(Boolean).length <= 2 && /^(bureau|salle|local|piece)\s*\d+/i.test(firstCell))) {
          const val = firstCell.replace(/^(bureau|salle|local|piece)\s*[:\-]?\s*/i, '').trim();
          if (val) currentBureau = val || firstCell;
          continue;
        }

        // Detect section title for Bloc
        if (firstCellNorm.startsWith('bloc') || firstCellNorm.startsWith('batiment')) {
          const val = firstCell.replace(/^(bloc|batiment)\s*[:\-]?\s*/i, '').trim();
          if (val) currentBloc = val;
          continue;
        }
      }

      if (r <= headerRowIndex) {
        continue;
      }

      // Extract item fields
      let direction = currentDirection;
      let bureau = currentBureau;
      let bloc = currentBloc;
      let code = '';
      let designation = '';
      let quantite = 1;
      let etat = 'Bon';
      let date = '';
      let observations = '';

      if (headerRowIndex !== -1) {
        if (headerMap.direction !== undefined && row[headerMap.direction]) direction = String(row[headerMap.direction]).trim();
        if (headerMap.bureau !== undefined && row[headerMap.bureau]) bureau = String(row[headerMap.bureau]).trim();
        if (headerMap.bloc !== undefined && row[headerMap.bloc]) bloc = String(row[headerMap.bloc]).trim();
        if (headerMap.code !== undefined && row[headerMap.code]) code = String(row[headerMap.code]).trim();
        if (headerMap.designation !== undefined && row[headerMap.designation]) designation = String(row[headerMap.designation]).trim();
        if (headerMap.quantite !== undefined && row[headerMap.quantite]) {
          const qVal = parseFloat(String(row[headerMap.quantite]).replace(',', '.'));
          if (!isNaN(qVal) && qVal > 0) quantite = qVal;
        }
        if (headerMap.etat !== undefined && row[headerMap.etat]) etat = String(row[headerMap.etat]).trim();
        if (headerMap.date !== undefined && row[headerMap.date]) date = String(row[headerMap.date]).trim();
        if (headerMap.observations !== undefined && row[headerMap.observations]) observations = String(row[headerMap.observations]).trim();
      } else {
        // Fallback positional heuristic: Code in col 0/1, Designation in col 1/2, Qté in numeric col
        const nonEmpties = row.map((v, i) => ({ val: String(v || '').trim(), idx: i })).filter(x => x.val);
        if (nonEmpties.length >= 2) {
          code = nonEmpties[0].val;
          designation = nonEmpties[1].val;
          if (nonEmpties.length >= 3) {
            const num = parseFloat(nonEmpties[2].val);
            if (!isNaN(num)) quantite = num;
            else etat = nonEmpties[2].val;
          }
        }
      }

      // Filter out total/subtotal lines
      const normDesig = normalizeHeader(designation);
      if (normDesig.startsWith('total') || normDesig.startsWith('sous total') || normDesig.startsWith('nombre total')) {
        continue;
      }

      // If both code and designation are empty, skip empty row
      if (!code && !designation) {
        continue;
      }

      // Auto-clean quantity
      if (isNaN(quantite) || quantite <= 0) {
        quantite = 1;
      }

      items.push({
        id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        direction,
        bureau,
        code,
        designation: designation || code,
        quantite,
        etat: etat || 'Bon',
        date,
        bloc,
        observations,
        sourceLine: r + 1,
        rawText: rowText
      });
    }
  }

  const commission = extractCommissionInfo(allLines);

  return {
    items,
    commission,
    rawText: allLines.join('\n'),
    warnings
  };
}

/**
 * Parse a Word (.docx) file
 */
export async function parseWordFile(file: File): Promise<ParseResult> {
  const buffer = await file.arrayBuffer();
  // Extract both HTML (for tables) and raw text (for paragraphs/commission)
  const [htmlResult, textResult] = await Promise.all([
    mammoth.convertToHtml({ arrayBuffer: buffer }),
    mammoth.extractRawText({ arrayBuffer: buffer })
  ]);

  const rawText = textResult.value || '';
  const lines = rawText.split('\n').map(l => l.trim()).filter(Boolean);
  const commission = extractCommissionInfo(lines);
  const items: InventoryItem[] = [];
  const warnings: string[] = [];

  // Parse HTML tables
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlResult.value || '', 'text/html');
  const tables = Array.from(doc.querySelectorAll('table'));

  let currentDirection = '';
  let currentBureau = '';
  let currentBloc = '';

  // Look for headings preceding tables or inside paragraphs
  const elements = Array.from(doc.body.children);
  for (const el of elements) {
    const text = el.textContent?.trim() || '';
    if (!text) continue;

    if (isCommissionLine(text)) continue;

    const norm = normalizeHeader(text);
    if (norm.startsWith('direction') || norm.startsWith('departement')) {
      const val = text.replace(/^(direction|departement|service)\s*[:\-]?\s*/i, '').trim();
      if (val) currentDirection = val;
    } else if (norm.startsWith('bureau') || norm.startsWith('salle') || norm.startsWith('local')) {
      const val = text.replace(/^(bureau|salle|local)\s*[:\-]?\s*/i, '').trim();
      if (val) currentBureau = val || text;
    } else if (norm.startsWith('bloc') || norm.startsWith('batiment')) {
      const val = text.replace(/^(bloc|batiment)\s*[:\-]?\s*/i, '').trim();
      if (val) currentBloc = val;
    }

    if (el.tagName.toLowerCase() === 'table') {
      const rows = Array.from(el.querySelectorAll('tr'));
      if (rows.length === 0) continue;

      let headerMap: { [key in keyof typeof COLUMN_ALIASES]?: number } = {};
      let headerRowIndex = -1;

      // Scan rows for header
      for (let r = 0; r < Math.min(rows.length, 5); r++) {
        const cells = Array.from(rows[r].querySelectorAll('th, td')).map(c => c.textContent?.trim() || '');
        const candidateMap: { [key in keyof typeof COLUMN_ALIASES]?: number } = {};
        let matches = 0;

        cells.forEach((cell, idx) => {
          const normCell = normalizeHeader(cell);
          for (const [field, aliases] of Object.entries(COLUMN_ALIASES) as [keyof typeof COLUMN_ALIASES, string[]][]) {
            if (aliases.some(alias => normCell === alias || normCell.startsWith(alias) || normCell.endsWith(alias))) {
              if (candidateMap[field] === undefined) {
                candidateMap[field] = idx;
                matches++;
              }
            }
          }
        });

        if (matches >= 2 || candidateMap.designation !== undefined || (candidateMap.code !== undefined && candidateMap.quantite !== undefined)) {
          headerMap = candidateMap;
          headerRowIndex = r;
          break;
        }
      }

      for (let r = headerRowIndex + 1; r < rows.length; r++) {
        const cells = Array.from(rows[r].querySelectorAll('td')).map(c => c.textContent?.trim() || '');
        if (cells.length === 0 || cells.every(c => !c)) continue;

        const rowText = cells.join(' ');
        if (isCommissionLine(rowText)) continue;

        let direction = currentDirection;
        let bureau = currentBureau;
        let bloc = currentBloc;
        let code = '';
        let designation = '';
        let quantite = 1;
        let etat = 'Bon';
        let date = '';
        let observations = '';

        if (headerRowIndex !== -1) {
          if (headerMap.direction !== undefined && cells[headerMap.direction]) direction = cells[headerMap.direction];
          if (headerMap.bureau !== undefined && cells[headerMap.bureau]) bureau = cells[headerMap.bureau];
          if (headerMap.bloc !== undefined && cells[headerMap.bloc]) bloc = cells[headerMap.bloc];
          if (headerMap.code !== undefined && cells[headerMap.code]) code = cells[headerMap.code];
          if (headerMap.designation !== undefined && cells[headerMap.designation]) designation = cells[headerMap.designation];
          if (headerMap.quantite !== undefined && cells[headerMap.quantite]) {
            const q = parseFloat(cells[headerMap.quantite].replace(',', '.'));
            if (!isNaN(q) && q > 0) quantite = q;
          }
          if (headerMap.etat !== undefined && cells[headerMap.etat]) etat = cells[headerMap.etat];
          if (headerMap.date !== undefined && cells[headerMap.date]) date = cells[headerMap.date];
          if (headerMap.observations !== undefined && cells[headerMap.observations]) observations = cells[headerMap.observations];
        } else {
          code = cells[0] || '';
          designation = cells[1] || code;
          if (cells[2]) {
            const q = parseFloat(cells[2].replace(',', '.'));
            if (!isNaN(q)) quantite = q;
            else etat = cells[2];
          }
        }

        const normD = normalizeHeader(designation);
        if (normD.startsWith('total') || normD.startsWith('sous total')) continue;
        if (!code && !designation) continue;

        items.push({
          id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          direction,
          bureau,
          code,
          designation: designation || code,
          quantite,
          etat: etat || 'Bon',
          date,
          bloc,
          observations,
          sourceLine: r + 1,
          rawText: rowText
        });
      }
    }
  }

  // If no tables were detected in Word, parse text lines
  if (items.length === 0 && lines.length > 0) {
    parseTextLinesToItems(lines, items, currentDirection, currentBureau);
  }

  return {
    items,
    commission,
    rawText,
    warnings
  };
}

/**
 * Parse a standard or scanned PDF file
 */
export async function parsePdfFile(file: File, progressCallback?: (page: number, total: number, msg: string) => void): Promise<ParseResult> {
  const buffer = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({ data: buffer });
  const pdf = await loadingTask.promise;
  const numPages = pdf.numPages;
  const warnings: string[] = [];
  const rawPageTexts: string[] = [];

  let isScanned = false;
  let totalExtractedChars = 0;

  // Step 1: Extract native text layer
  const pageLines: { y: number; x: number; text: string; page: number }[][] = [];

  for (let p = 1; p <= numPages; p++) {
    if (progressCallback) progressCallback(p, numPages, `Extraction de la page ${p}/${numPages}...`);
    const page = await pdf.getPage(p);
    const textContent = await page.getTextContent();
    const items = textContent.items as any[];

    let pageText = '';
    const lineMap: { y: number; x: number; text: string; page: number }[] = [];

    for (const item of items) {
      if (item.str && item.str.trim()) {
        const text = item.str.trim();
        pageText += text + ' ';
        const transform = item.transform; // [scaleX, skewY, skewX, scaleY, transX, transY]
        const x = transform ? transform[4] : 0;
        const y = transform ? Math.round(transform[5] / 4) * 4 : 0; // Quantize y for line grouping
        lineMap.push({ y, x, text, page: p });
      }
    }

    rawPageTexts.push(pageText);
    totalExtractedChars += pageText.replace(/\s+/g, '').length;
    pageLines.push(lineMap);
  }

  // If text layer is sparse (< 25 chars per page on average), it's likely a scanned document
  if (totalExtractedChars < numPages * 25) {
    isScanned = true;
    warnings.push("Document PDF scanné détecté (aucune couche de texte numérique trouvée). L'OCR client est prêt à être activé.");
  }

  const allLines: string[] = [];
  const items: InventoryItem[] = [];
  let currentDirection = '';
  let currentBureau = '';
  let currentBloc = '';

  for (let p = 0; p < pageLines.length; p++) {
    const linesOnPage = pageLines[p];
    // Group tokens by vertical Y position
    const yGroups: { [y: number]: { x: number; text: string }[] } = {};
    for (const token of linesOnPage) {
      if (!yGroups[token.y]) yGroups[token.y] = [];
      yGroups[token.y].push({ x: token.x, text: token.text });
    }

    // Sort y descending (PDF origin is bottom-left)
    const sortedYs = Object.keys(yGroups).map(Number).sort((a, b) => b - a);

    for (const y of sortedYs) {
      const tokens = yGroups[y].sort((a, b) => a.x - b.x);
      const rowLine = tokens.map(t => t.text).join('   ').trim();
      if (!rowLine) continue;
      allLines.push(rowLine);

      if (isCommissionLine(rowLine)) continue;

      const norm = normalizeHeader(rowLine);
      if (norm.startsWith('direction') || norm.startsWith('departement')) {
        const val = rowLine.replace(/^(direction|departement|service)\s*[:\-]?\s*/i, '').trim();
        if (val) currentDirection = val;
        continue;
      }
      if (norm.startsWith('bureau') || norm.startsWith('salle') || norm.startsWith('local')) {
        const val = rowLine.replace(/^(bureau|salle|local)\s*[:\-]?\s*/i, '').trim();
        if (val) currentBureau = val || rowLine;
        continue;
      }
      if (norm.startsWith('bloc') || norm.startsWith('batiment')) {
        const val = rowLine.replace(/^(bloc|batiment)\s*[:\-]?\s*/i, '').trim();
        if (val) currentBloc = val;
        continue;
      }

      // Check if this row looks like an inventory row
      // Typical format: [CODE] [DESIGNATION] [QTE] [ETAT]
      if (tokens.length >= 2) {
        let code = '';
        let designation = '';
        let quantite = 1;
        let etat = 'Bon';
        let observations = '';

        // Check if token 0 looks like an inventory code (e.g. INV-001, 10245, A12-40)
        const t0 = tokens[0].text.trim();
        const t1 = tokens[1].text.trim();

        if (/^[A-Za-z0-9\/\.\-_]{3,}$/.test(t0) && !/^(total|direction|bureau|page|date|code)/i.test(t0)) {
          code = t0;
          designation = t1;
          for (let i = 2; i < tokens.length; i++) {
            const txt = tokens[i].text.trim();
            const num = parseFloat(txt);
            if (!isNaN(num) && num > 0 && num < 10000 && quantite === 1) {
              quantite = num;
            } else if (/^(bon|mauvais|moyen|hs|hors service|reforme|neuf|passable)$/i.test(txt)) {
              etat = txt;
            } else {
              designation += ' ' + txt;
            }
          }
        } else {
          // Fallback line split
          const parts = rowLine.split(/\s{2,}|\t/);
          if (parts.length >= 2) {
            code = parts[0].trim();
            designation = parts[1].trim();
          }
        }

        if (code || (designation && designation.length > 3)) {
          const normD = normalizeHeader(designation);
          if (!normD.startsWith('total') && !normD.startsWith('sous total') && !normD.includes('page ')) {
            items.push({
              id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
              direction: currentDirection,
              bureau: currentBureau,
              code: code || `INV-${items.length + 1}`,
              designation: designation || code,
              quantite,
              etat,
              date: '',
              bloc: currentBloc,
              observations,
              sourceLine: allLines.length,
              rawText: rowLine
            });
          }
        }
      }
    }
  }

  const commission = extractCommissionInfo(allLines);

  return {
    items,
    commission,
    rawText: allLines.join('\n'),
    isScanned,
    warnings
  };
}

/**
 * Run Client-side OCR on a scanned PDF using Tesseract.js and HTML5 Canvas
 */
export async function runOcrOnScannedPdf(
  file: File,
  onProgress?: (progress: number, status: string) => void
): Promise<ParseResult> {
  const buffer = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({ data: buffer });
  const pdf = await loadingTask.promise;
  const numPages = pdf.numPages;

  if (onProgress) onProgress(5, "Initialisation du moteur d'OCR...");

  let worker: any = null;
  try {
    worker = await createWorker('fra');
  } catch (e) {
    // If French language file is missing or offline fallback
    try {
      worker = await createWorker();
    } catch (err) {
      console.warn("Tesseract worker init error, fallback:", err);
    }
  }

  const ocrLines: string[] = [];

  for (let p = 1; p <= numPages; p++) {
    if (onProgress) {
      const pct = Math.round(10 + ((p - 1) / numPages) * 80);
      onProgress(pct, `Reconnaissance optique de la page ${p}/${numPages}...`);
    }

    const page = await pdf.getPage(p);
    const viewport = page.getViewport({ scale: 2.0 }); // Higher scale for crisp OCR
    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      await (page.render({ canvasContext: ctx, viewport, canvas } as any)).promise;

      if (worker) {
        const ret = await worker.recognize(canvas);
        const text = ret.data.text || '';
        const lines = text.split('\n').map((l: string) => l.trim()).filter(Boolean);
        ocrLines.push(...lines);
      }
    }
  }

  if (worker) {
    await worker.terminate();
  }

  if (onProgress) onProgress(95, "Extraction et structuration des biens...");

  const items: InventoryItem[] = [];
  parseTextLinesToItems(ocrLines, items, '', '');
  const commission = extractCommissionInfo(ocrLines);

  if (onProgress) onProgress(100, "OCR terminé avec succès !");

  return {
    items,
    commission,
    rawText: ocrLines.join('\n'),
    warnings: []
  };
}

/**
 * Helper to parse unstructured text lines into Inventory Items
 */
function parseTextLinesToItems(lines: string[], items: InventoryItem[], initialDirection: string, initialBureau: string) {
  let direction = initialDirection;
  let bureau = initialBureau;
  let bloc = '';

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (isCommissionLine(line)) continue;

    const norm = normalizeHeader(line);
    if (norm.startsWith('direction') || norm.startsWith('departement')) {
      const val = line.replace(/^(direction|departement|service)\s*[:\-]?\s*/i, '').trim();
      if (val) direction = val;
      continue;
    }
    if (norm.startsWith('bureau') || norm.startsWith('salle') || norm.startsWith('local')) {
      const val = line.replace(/^(bureau|salle|local)\s*[:\-]?\s*/i, '').trim();
      if (val) bureau = val || line;
      continue;
    }
    if (norm.startsWith('bloc') || norm.startsWith('batiment')) {
      const val = line.replace(/^(bloc|batiment)\s*[:\-]?\s*/i, '').trim();
      if (val) bloc = val;
      continue;
    }

    // Delimited row or key-value row
    const parts = line.split(/[;|\t]|\s{2,}/).map(s => s.trim()).filter(Boolean);
    if (parts.length >= 2) {
      const code = parts[0];
      const designation = parts[1];
      let quantite = 1;
      let etat = 'Bon';
      let obs = '';

      if (parts[2]) {
        const q = parseFloat(parts[2].replace(',', '.'));
        if (!isNaN(q) && q > 0) quantite = q;
        else etat = parts[2];
      }
      if (parts[3]) {
        if (/^(bon|mauvais|moyen|hs|reforme|neuf)$/i.test(parts[3])) etat = parts[3];
        else obs = parts[3];
      }

      if (!normalizeHeader(designation).startsWith('total')) {
        items.push({
          id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          direction,
          bureau,
          code,
          designation,
          quantite,
          etat,
          date: '',
          bloc,
          observations: obs,
          sourceLine: i + 1,
          rawText: line
        });
      }
    }
  }
}
