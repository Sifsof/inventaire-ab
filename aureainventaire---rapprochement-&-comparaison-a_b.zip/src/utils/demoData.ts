import { InventoryItem, CommissionInfo } from '../types/inventory';

export const DEMO_COMMISSION_A: CommissionInfo = {
  detected: true,
  president: "M. Jean-Marc LAROCHE (Inspecteur Général des Finances)",
  membres: [
    "Mme Sophie BENAMARA (Chef du Service du Patrimoine)",
    "M. Pierre DUVIVIER (Comptable Matières)",
    "Mme Claire MOREL (Représentante du Contrôle Interne)"
  ],
  datePV: "Fait à Paris, le 15 Octobre 2026",
  lieu: "Siège Administratif Central",
  visa: "Visa n° PV-INV-2026-088",
  rawTextLines: [
    "COMMISSION D'INVENTAIRE DU GROUPE A (RÉFÉRENTIEL COMPTABLE)",
    "Président : M. Jean-Marc LAROCHE (Inspecteur Général des Finances)",
    "Membres : Mme Sophie BENAMARA, M. Pierre DUVIVIER, Mme Claire MOREL",
    "Visa de clôture : Fait à Paris, le 15 Octobre 2026"
  ]
};

export const DEMO_COMMISSION_B: CommissionInfo = {
  detected: true,
  president: "M. Ahmed BELKACEM (Auditeur Externe Indépendant)",
  membres: [
    "Mme Valérie GAUTHIER (Responsable Inventaire Physique Terrain)",
    "M. Karim TAZI (Opérateur Recensement Code-Barres)",
    "M. David LEROY (Agent Logistique)"
  ],
  datePV: "Fait sur site, le 21 Octobre 2026",
  lieu: "Sites d'exploitation & Agences",
  visa: "Contrôle contradictoire n° CC-2026-B",
  rawTextLines: [
    "COMMISSION DE RÉCOLEMENT PHYSIQUE GROUPE B (RECENSEMENT TERRAIN)",
    "Président : M. Ahmed BELKACEM (Auditeur Externe Indépendant)",
    "Membres : Mme Valérie GAUTHIER, M. Karim TAZI, M. David LEROY",
    "Visa de clôture : Fait sur site, le 21 Octobre 2026"
  ]
};

export const DEMO_ITEMS_A: InventoryItem[] = [
  // Bureau 101 - DAF
  {
    id: 'demo-a-1',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 101 - Chef de Service',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00101',
    designation: 'Bureau exécutif en chêne massif 180x90cm avec retour',
    quantite: 1,
    etat: 'Bon',
    date: '12/03/2023',
    observations: 'Mobilier de direction sous garantie'
  },
  {
    id: 'demo-a-2',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 101 - Chef de Service',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00102',
    designation: 'Fauteuil ergonomique cuir noir accoudoirs réglables',
    quantite: 1,
    etat: 'Bon',
    date: '12/03/2023',
    observations: 'Marque Steelcase'
  },
  {
    id: 'demo-a-3',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 101 - Chef de Service',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00103',
    designation: 'Chaises visiteurs tissu noir pieds chromés',
    quantite: 4,
    etat: 'Bon',
    date: '14/04/2023',
    observations: 'Lot de 4 chaises devant le bureau'
  },
  {
    id: 'demo-a-4',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 101 - Chef de Service',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00104',
    designation: 'Écran de contrôle 27 pouces Dell UltraSharp 4K',
    quantite: 1,
    etat: 'Bon',
    date: '10/06/2024',
    observations: 'N/S: CN-0XY128'
  },
  {
    id: 'demo-a-5',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 101 - Chef de Service',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00105',
    designation: 'Ordinateur portable Lenovo ThinkPad T14 Gen 4',
    quantite: 1,
    etat: 'Bon',
    date: '02/09/2024',
    observations: 'Affecté au DAF en mobilité'
  },

  // Bureau 102 - Comptabilité
  {
    id: 'demo-a-6',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 102 - Comptabilité Fournisseurs',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00201',
    designation: 'Armoire métallique haute 2 portes battantes avec serrure',
    quantite: 2,
    etat: 'Bon',
    date: '15/01/2022',
    observations: 'Archivage factures courantes'
  },
  {
    id: 'demo-a-7',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 102 - Comptabilité Fournisseurs',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00202',
    designation: 'Imprimante réseau multifonction HP LaserJet Pro M428',
    quantite: 1,
    etat: 'Bon',
    date: '05/05/2023',
    observations: 'Bailleur agréé'
  },
  {
    id: 'demo-a-8',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 102 - Comptabilité Fournisseurs',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00203',
    designation: 'Poste de travail complet HP ProDesk avec double écran',
    quantite: 3,
    etat: 'Bon',
    date: '18/02/2023',
    observations: '3 postes collaborateurs'
  },

  // Bureau 204 - DSI
  {
    id: 'demo-a-9',
    direction: 'DIRECTION DES SYSTÈMES D\'INFORMATION',
    bureau: 'Bureau 204 - Salle Serveurs & Réseaux',
    bloc: 'Bâtiment Technique - Rez-de-chaussée',
    code: 'INV-2024-00301',
    designation: 'Baie de brassage 42U avec portes vitrées ventilées',
    quantite: 2,
    etat: 'Bon',
    date: '10/11/2022',
    observations: 'Rack principal de production'
  },
  {
    id: 'demo-a-10',
    direction: 'DIRECTION DES SYSTÈMES D\'INFORMATION',
    bureau: 'Bureau 204 - Salle Serveurs & Réseaux',
    bloc: 'Bâtiment Technique - Rez-de-chaussée',
    code: 'INV-2024-00302',
    designation: 'Onduleur rackable APC Smart-UPS 3000VA',
    quantite: 2,
    etat: 'Bon',
    date: '12/11/2022',
    observations: 'Batteries vérifiées en 2025'
  },
  {
    id: 'demo-a-11',
    direction: 'DIRECTION DES SYSTÈMES D\'INFORMATION',
    bureau: 'Bureau 204 - Salle Serveurs & Réseaux',
    bloc: 'Bâtiment Technique - Rez-de-chaussée',
    code: 'INV-2024-00303',
    designation: 'Commutateur réseau Cisco Catalyst 48 ports PoE+',
    quantite: 4,
    etat: 'Bon',
    date: '15/12/2022',
    observations: 'Cœur de réseau'
  },

  // Bureau 305 - DRH
  {
    id: 'demo-a-12',
    direction: 'DIRECTION DES RESSOURCES HUMAINES',
    bureau: 'Bureau 305 - Espace Recrutement',
    bloc: 'Bâtiment Principal - 3ème Étage',
    code: 'INV-2024-00401',
    designation: 'Table de réunion ovale 6 personnes piètement métal',
    quantite: 1,
    etat: 'Bon',
    date: '20/03/2024',
    observations: 'Salle d\'entretien candidats'
  },
  {
    id: 'demo-a-13',
    direction: 'DIRECTION DES RESSOURCES HUMAINES',
    bureau: 'Bureau 305 - Espace Recrutement',
    bloc: 'Bâtiment Principal - 3ème Étage',
    code: 'INV-2024-00402',
    designation: 'Fauteuil luge visiteur tissu gris chiné',
    quantite: 6,
    etat: 'Bon',
    date: '20/03/2024',
    observations: 'Autour de la table ovale'
  }
];

export const DEMO_ITEMS_B: InventoryItem[] = [
  // Bureau 101 - DAF
  {
    id: 'demo-b-1',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 101 - Chef de Service',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00101',
    designation: 'Bureau exécutif en chêne massif 180x90cm avec retour',
    quantite: 1,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Constaté en place conforme'
  },
  {
    id: 'demo-b-2',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 101 - Chef de Service',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00102',
    designation: 'Fauteuil ergonomique cuir noir accoudoirs réglables',
    quantite: 1,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Bon état général'
  },
  // Écart Quantité : 2 trouvées sur le terrain au lieu de 4 prévues
  {
    id: 'demo-b-3',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 101 - Chef de Service',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00103',
    designation: 'Chaises visiteurs tissu noir pieds chromés',
    quantite: 2,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Seulement 2 chaises présentes (2 manquantes)'
  },
  // NOTE : INV-2024-00104 (Écran Dell) n'est PAS dans le 101, il a été déplacé dans le bureau 102 !
  // NOTE : INV-2024-00105 (PC ThinkPad) absent du recensement physique terrain !

  // Bureau 102 - Comptabilité
  {
    id: 'demo-b-4',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 102 - Comptabilité Fournisseurs',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00201',
    designation: 'Armoire métallique haute 2 portes battantes avec serrure',
    quantite: 2,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Conforme'
  },
  // Écart d'état : Imprimante constatée Hors Service
  {
    id: 'demo-b-5',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 102 - Comptabilité Fournisseurs',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00202',
    designation: 'Imprimante réseau multifonction HP LaserJet Pro M428',
    quantite: 1,
    etat: 'Hors service',
    date: '21/10/2026',
    observations: 'Message erreur carte mère clignotant, non fonctionnelle'
  },
  {
    id: 'demo-b-6',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 102 - Comptabilité Fournisseurs',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00203',
    designation: 'Poste de travail complet HP ProDesk avec double écran',
    quantite: 3,
    etat: 'Bon',
    date: '21/10/2026',
    observations: '3 postes opérationnels'
  },
  // Bien déplacé physiquement depuis le Bureau 101 !
  {
    id: 'demo-b-7',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 102 - Comptabilité Fournisseurs',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-2024-00104',
    designation: 'Écran de contrôle 27 pouces Dell UltraSharp 4K',
    quantite: 1,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Retrouvé sur la table d\'appoint du Bureau 102 sans fiche de transfert'
  },
  // Surplus constaté sur le terrain (Absent du Groupe A)
  {
    id: 'demo-b-8',
    direction: 'DIRECTION DES AFFAIRES FINANCIÈRES',
    bureau: 'Bureau 102 - Comptabilité Fournisseurs',
    bloc: 'Bâtiment Principal - 1er Étage',
    code: 'INV-PHY-9901',
    designation: 'Destructeur de documents professionnel Rexel ProStyle+',
    quantite: 1,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Achat direct sur petite caisse, non enregistré au grand livre'
  },

  // Bureau 204 - DSI
  {
    id: 'demo-b-9',
    direction: 'DIRECTION DES SYSTÈMES D\'INFORMATION',
    bureau: 'Bureau 204 - Salle Serveurs & Réseaux',
    bloc: 'Bâtiment Technique - Rez-de-chaussée',
    code: 'INV-2024-00301',
    designation: 'Baie de brassage 42U avec portes vitrées ventilées',
    quantite: 2,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Conforme'
  },
  {
    id: 'demo-b-10',
    direction: 'DIRECTION DES SYSTÈMES D\'INFORMATION',
    bureau: 'Bureau 204 - Salle Serveurs & Réseaux',
    bloc: 'Bâtiment Technique - Rez-de-chaussée',
    code: 'INV-2024-00302',
    designation: 'Onduleur rackable APC Smart-UPS 3000VA',
    quantite: 2,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Voyants verts nominaux'
  },
  {
    id: 'demo-b-11',
    direction: 'DIRECTION DES SYSTÈMES D\'INFORMATION',
    bureau: 'Bureau 204 - Salle Serveurs & Réseaux',
    bloc: 'Bâtiment Technique - Rez-de-chaussée',
    code: 'INV-2024-00303',
    designation: 'Commutateur réseau Cisco Catalyst 48 ports PoE+',
    quantite: 4,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Conforme'
  },

  // Bureau 305 - DRH
  {
    id: 'demo-b-12',
    direction: 'DIRECTION DES RESSOURCES HUMAINES',
    bureau: 'Bureau 305 - Espace Recrutement',
    bloc: 'Bâtiment Principal - 3ème Étage',
    code: 'INV-2024-00401',
    designation: 'Table de réunion ovale 6 personnes piètement métal',
    quantite: 1,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Conforme'
  },
  {
    id: 'demo-b-13',
    direction: 'DIRECTION DES RESSOURCES HUMAINES',
    bureau: 'Bureau 305 - Espace Recrutement',
    bloc: 'Bâtiment Principal - 3ème Étage',
    code: 'INV-2024-00402',
    designation: 'Fauteuil luge visiteur tissu gris chiné',
    quantite: 6,
    etat: 'Bon',
    date: '21/10/2026',
    observations: 'Conforme'
  }
];
