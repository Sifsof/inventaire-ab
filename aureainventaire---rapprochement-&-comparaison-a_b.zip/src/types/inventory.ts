export interface InventoryItem {
  id: string;
  direction: string;
  bureau: string;
  code: string;
  designation: string;
  quantite: number;
  etat: string;
  date: string;
  bloc: string;
  observations: string;
  sourceLine?: number;
  rawText?: string;
  isDuplicate?: boolean;
}

export interface CommissionInfo {
  detected: boolean;
  president?: string;
  membres: string[];
  datePV?: string;
  lieu?: string;
  visa?: string;
  rawTextLines: string[];
}

export type MatchStatus =
  | 'commun_conforme'
  | 'ecart_quantite'
  | 'ecart_etat'
  | 'absent_a'
  | 'absent_b'
  | 'doublon'
  | 'a_verifier';

export interface MatchPair {
  id: string;
  status: MatchStatus;
  statusLabel: string;
  itemA?: InventoryItem;
  itemB?: InventoryItem;
  confidence: number; // 0 to 100
  matchReason: string;
  quantiteDelta?: number; // itemB.quantite - itemA.quantite
  isLocationMismatch?: boolean; // detected in different bureau/direction
  resolvedManually?: boolean;
  manualNotes?: string;
}

export interface ProbableCause {
  title: string;
  description: string;
  count: number;
  category: 'logistique' | 'saisie' | 'degradation' | 'patrimoine' | 'conformite';
}

export interface ReconciliationSummary {
  totalItemsA: number;
  totalQuantiteA: number;
  totalItemsB: number;
  totalQuantiteB: number;
  totalUniqueAssets: number;
  
  conformeCount: number;
  ecartQuantiteCount: number;
  ecartEtatCount: number;
  absentACount: number;
  absentBCount: number;
  doublonCount: number;
  aVerifierCount: number;

  tauxConcordance: number; // Pourcentage strict
  tauxIdentification: number; // Taux de biens retrouvés
  methodologieCalcul: string;

  causesProbables: ProbableCause[];
  recommandations: string[];
}

export interface AuditSession {
  id: string;
  title: string;
  savedAt: string;
  fileNameA: string;
  fileNameB: string;
  fileTypeA: string;
  fileTypeB: string;
  itemsA: InventoryItem[];
  itemsB: InventoryItem[];
  commissionA: CommissionInfo;
  commissionB: CommissionInfo;
  pairs: MatchPair[];
  summary: ReconciliationSummary;
  customIcon?: string;
}
