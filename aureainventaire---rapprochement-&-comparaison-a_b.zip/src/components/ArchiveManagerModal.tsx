import React, { useRef } from 'react';
import { 
  Archive, 
  RotateCcw, 
  Download, 
  Upload, 
  Trash2, 
  X, 
  Calendar, 
  Percent, 
  FileSpreadsheet, 
  CheckCircle2,
  Clock
} from 'lucide-react';
import { AuditSession } from '../types/inventory';

interface ArchiveManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  archives: AuditSession[];
  onRestoreArchive: (session: AuditSession) => void;
  onDeleteArchive: (id: string) => void;
  onImportArchive: (session: AuditSession) => void;
}

export const ArchiveManagerModal: React.FC<ArchiveManagerModalProps> = ({
  isOpen,
  onClose,
  archives,
  onRestoreArchive,
  onDeleteArchive,
  onImportArchive
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleExportJson = (session: AuditSession) => {
    const jsonStr = JSON.stringify(session, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Archive_Inventaire_${session.title.replace(/\s+/g, '_')}_${session.savedAt.slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const content = event.target?.result as string;
          const parsed = JSON.parse(content) as AuditSession;
          if (parsed && parsed.itemsA && parsed.itemsB) {
            onImportArchive(parsed);
          } else {
            alert("Format d'archive JSON invalide.");
          }
        } catch (err: any) {
          alert(`Erreur lors de l'importation de l'archive : ${err.message}`);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm p-4 flex items-center justify-center">
      <div className="bg-[#0e111a] border border-[#242b3d] rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="p-4 bg-[#121622] border-b border-[#212738] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#d4af37]/15 text-[#dfb743] border border-[#d4af37]/30 flex items-center justify-center">
              <Archive className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif text-sm font-bold text-slate-100">
                Gestionnaire des Archives Locales
              </h3>
              <p className="text-[11px] text-slate-400">
                Historique des rapprochements passés enregistrés dans votre navigateur hors-ligne
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-2.5 py-1.5 text-xs font-medium text-amber-200 bg-[#161c2b] hover:bg-[#1f283d] border border-[#d4af37]/30 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5 text-[#d4af37]" />
              Importer fichier JSON
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleFileChange}
            />
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-[#181d2c]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content List */}
        <div className="overflow-y-auto p-4 space-y-3">
          {archives.length === 0 ? (
            <div className="text-center py-12 space-y-2">
              <Archive className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-sm font-medium text-slate-400">
                Aucune session d'inventaire archivée
              </p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Cliquez sur le bouton « Archiver » dans la barre supérieure pour enregistrer vos rapprochements en cours.
              </p>
            </div>
          ) : (
            archives.map(session => (
              <div 
                key={session.id}
                className="p-3.5 rounded-xl bg-[#121622] border border-[#21283c] hover:border-[#d4af37]/40 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-xs text-slate-100">
                      {session.title}
                    </span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-[#d4af37]/15 text-[#dfb743] border border-[#d4af37]/30">
                      {session.summary?.tauxConcordance ?? 0}% concordance
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {new Date(session.savedAt).toLocaleString('fr-FR')}
                    </span>
                    <span>·</span>
                    <span>A: {session.itemsA.length} biens ({session.fileNameA || 'Fichier A'})</span>
                    <span>·</span>
                    <span>B: {session.itemsB.length} biens ({session.fileNameB || 'Fichier B'})</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => handleExportJson(session)}
                    className="p-1.5 text-slate-400 hover:text-amber-300 rounded hover:bg-[#1a2030] transition-colors"
                    title="Télécharger l'archive JSON"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onRestoreArchive(session)}
                    className="px-3 py-1 text-xs font-semibold text-slate-900 bg-gradient-to-r from-[#d4af37] to-amber-300 hover:from-amber-400 rounded-lg transition-all flex items-center gap-1"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Restaurer
                  </button>

                  <button
                    onClick={() => onDeleteArchive(session.id)}
                    className="p-1.5 text-slate-400 hover:text-red-400 rounded hover:bg-[#22181c] transition-colors"
                    title="Supprimer cette archive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
