import React, { useRef } from 'react';
import { 
  Layers, 
  RotateCcw, 
  Archive, 
  Sparkles, 
  Printer, 
  Upload, 
  CheckCircle2, 
  ShieldCheck, 
  FileSpreadsheet,
  Image as ImageIcon
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'reconciliation' | 'groupA' | 'groupB' | 'report' | 'archives';
  setActiveTab: (tab: 'reconciliation' | 'groupA' | 'groupB' | 'report' | 'archives') => void;
  countA: number;
  countB: number;
  concordanceRate: number;
  hasData: boolean;
  onReset: () => void;
  onArchive: () => void;
  onLoadDemo: () => void;
  onOpenReport: () => void;
  customIcon?: string;
  onCustomIconChange: (dataUrl: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  countA,
  countB,
  concordanceRate,
  hasData,
  onReset,
  onArchive,
  onLoadDemo,
  onOpenReport,
  customIcon,
  onCustomIconChange
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onCustomIconChange(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#090b10]/95 backdrop-blur-md border-b border-[#242938]">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-6">
          
          {/* ZONE 1: BRAND LOGO & TITLE */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()} title="Cliquez pour changer le logo / icône d'audit">
              {customIcon ? (
                <img 
                  src={customIcon} 
                  alt="Logo Personnalisé" 
                  className="w-9 h-9 rounded-lg object-contain bg-[#121622] border border-[#d4af37]/40 p-0.5 shadow-md"
                />
              ) : (
                <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#d4af37]/20 via-[#161a26] to-[#0c0e14] border border-[#d4af37]/50 flex items-center justify-center text-[#d4af37] shadow-[0_0_15px_rgba(212,175,55,0.15)] group-hover:border-[#d4af37] transition-all">
                  <ShieldCheck className="w-5 h-5 text-[#dfb743]" />
                </div>
              )}
              <div className="absolute -bottom-1 -right-1 bg-[#121520] rounded-full p-0.5 border border-[#30374c] opacity-0 group-hover:opacity-100 transition-opacity">
                <ImageIcon className="w-2.5 h-2.5 text-[#d4af37]" />
              </div>
              <input 
                ref={fileInputRef} 
                type="file" 
                accept="image/*" 
                className="hidden" 
                onChange={handleIconUpload} 
              />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-serif text-lg font-bold tracking-tight text-gold-gradient whitespace-nowrap">
                  AUREAINVENTAIRE
                </span>
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#d4af37]/80 bg-[#d4af37]/10 px-1.5 py-0.5 rounded border border-[#d4af37]/30">
                  Local 100% Hors-Ligne
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate max-w-[280px]">
                Rapprochement et Contrôle Patrimonial A/B
              </p>
            </div>
          </div>

          {/* ZONE 2: NAVIGATION TABS */}
          <nav className="hidden md:flex items-center gap-1 bg-[#10141f] p-1 rounded-xl border border-[#222736]">
            <button
              onClick={() => setActiveTab('reconciliation')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
                activeTab === 'reconciliation'
                  ? 'bg-gradient-to-r from-[#d4af37]/20 to-[#d4af37]/10 text-amber-300 border border-[#d4af37]/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#161b2a]'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Matrice & Synthèse
              {hasData && (
                <span className="text-[10px] font-mono px-1 rounded bg-[#090b10] text-[#d4af37] border border-[#d4af37]/30">
                  {concordanceRate}%
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('groupA')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
                activeTab === 'groupA'
                  ? 'bg-gradient-to-r from-[#d4af37]/20 to-[#d4af37]/10 text-amber-300 border border-[#d4af37]/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#161b2a]'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Groupe A
              <span className="text-[10px] font-mono text-slate-400">({countA})</span>
            </button>

            <button
              onClick={() => setActiveTab('groupB')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
                activeTab === 'groupB'
                  ? 'bg-gradient-to-r from-[#d4af37]/20 to-[#d4af37]/10 text-amber-300 border border-[#d4af37]/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#161b2a]'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Groupe B
              <span className="text-[10px] font-mono text-slate-400">({countB})</span>
            </button>

            <button
              onClick={onOpenReport}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
                activeTab === 'report'
                  ? 'bg-gradient-to-r from-[#d4af37]/20 to-[#d4af37]/10 text-amber-300 border border-[#d4af37]/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#161b2a]'
              }`}
            >
              <Printer className="w-3.5 h-3.5" />
              Procès-Verbal & A4
            </button>

            <button
              onClick={() => setActiveTab('archives')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap shrink-0 flex items-center gap-2 ${
                activeTab === 'archives'
                  ? 'bg-gradient-to-r from-[#d4af37]/20 to-[#d4af37]/10 text-amber-300 border border-[#d4af37]/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#161b2a]'
              }`}
            >
              <Archive className="w-3.5 h-3.5" />
              Archives
            </button>
          </nav>

          {/* ZONE 3: ACTIONS (Charger démo, Archiver, Vider) */}
          <div className="flex items-center gap-2 shrink-0">
            {!hasData ? (
              <button
                onClick={onLoadDemo}
                className="px-3.5 py-1.5 text-xs font-medium text-amber-200 bg-gradient-to-r from-[#d4af37]/20 to-[#a37f1b]/20 hover:from-[#d4af37]/30 hover:to-[#a37f1b]/30 border border-[#d4af37]/50 rounded-lg transition-all flex items-center gap-1.5 shadow-[0_0_12px_rgba(212,175,55,0.12)] whitespace-nowrap"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#dfb743]" />
                Charger Cas d'Étude Type
              </button>
            ) : (
              <>
                <button
                  onClick={onArchive}
                  title="Enregistrer l'état du rapprochement en archive locale"
                  className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-amber-200 bg-[#121622] hover:bg-[#1a2030] border border-[#2b3245] hover:border-[#d4af37]/40 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap"
                >
                  <Archive className="w-3.5 h-3.5 text-[#d4af37]" />
                  Archiver
                </button>

                <button
                  onClick={onReset}
                  title="Vider l'espace de travail sans modifier les fichiers locaux"
                  className="px-3 py-1.5 text-xs font-medium text-red-400 hover:text-red-300 bg-[#171214] hover:bg-[#24171a] border border-red-900/40 hover:border-red-700/60 rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Vider
                </button>
              </>
            )}
          </div>

        </div>
      </div>
    </header>
  );
};
