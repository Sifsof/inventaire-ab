import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  HelpCircle, 
  XCircle, 
  Copy, 
  Search, 
  ArrowRightLeft, 
  Building2, 
  MapPin, 
  Sparkles, 
  Check, 
  X,
  SlidersHorizontal,
  ChevronDown,
  Info
} from 'lucide-react';
import { MatchPair, MatchStatus } from '../types/inventory';

interface ReconciliationMatrixProps {
  pairs: MatchPair[];
  onUpdatePair: (updatedPair: MatchPair) => void;
}

export const ReconciliationMatrix: React.FC<ReconciliationMatrixProps> = ({
  pairs,
  onUpdatePair
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | MatchStatus>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBureau, setSelectedBureau] = useState('ALL');
  const [editingPairId, setEditingPairId] = useState<string | null>(null);
  const [manualNote, setManualNote] = useState('');

  // Extract distinct locations (bureau)
  const bureauxList = useMemo(() => {
    const set = new Set<string>();
    pairs.forEach(p => {
      if (p.itemA?.bureau) set.add(p.itemA.bureau);
      if (p.itemB?.bureau) set.add(p.itemB.bureau);
    });
    return Array.from(set).sort();
  }, [pairs]);

  // Counts by status
  const counts = useMemo(() => {
    const c = {
      all: pairs.length,
      commun_conforme: 0,
      ecart_quantite: 0,
      ecart_etat: 0,
      absent_b: 0,
      absent_a: 0,
      doublon: 0,
      a_verifier: 0
    };
    pairs.forEach(p => {
      if (c[p.status] !== undefined) {
        c[p.status]++;
      }
    });
    return c;
  }, [pairs]);

  // Filter pairs
  const filteredPairs = useMemo(() => {
    return pairs.filter(p => {
      // Status filter
      if (activeFilter !== 'all' && p.status !== activeFilter) return false;

      // Bureau filter
      if (selectedBureau !== 'ALL') {
        const burA = p.itemA?.bureau || '';
        const burB = p.itemB?.bureau || '';
        if (burA !== selectedBureau && burB !== selectedBureau) return false;
      }

      // Search term
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase();
        const codeA = p.itemA?.code?.toLowerCase() || '';
        const desA = p.itemA?.designation?.toLowerCase() || '';
        const codeB = p.itemB?.code?.toLowerCase() || '';
        const desB = p.itemB?.designation?.toLowerCase() || '';
        const burA = p.itemA?.bureau?.toLowerCase() || '';
        const burB = p.itemB?.bureau?.toLowerCase() || '';
        const reason = p.matchReason?.toLowerCase() || '';

        return (
          codeA.includes(term) ||
          desA.includes(term) ||
          codeB.includes(term) ||
          desB.includes(term) ||
          burA.includes(term) ||
          burB.includes(term) ||
          reason.includes(term)
        );
      }

      return true;
    });
  }, [pairs, activeFilter, selectedBureau, searchTerm]);

  // Helper for Status Badge styling
  const renderStatusBadge = (status: MatchStatus, isLocationMismatch?: boolean) => {
    switch (status) {
      case 'commun_conforme':
        return (
          <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-950/50 border border-emerald-800/50 px-2.5 py-1 rounded-md whitespace-nowrap">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Commun conforme
          </div>
        );
      case 'ecart_quantite':
        return (
          <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400 bg-amber-950/50 border border-amber-800/50 px-2.5 py-1 rounded-md whitespace-nowrap">
            <AlertTriangle className="w-3.5 h-3.5" />
            Écart de quantité
          </div>
        );
      case 'ecart_etat':
        return (
          <div className="flex items-center gap-1.5 text-xs font-semibold text-orange-400 bg-orange-950/50 border border-orange-800/50 px-2.5 py-1 rounded-md whitespace-nowrap">
            <SlidersHorizontal className="w-3.5 h-3.5" />
            Écart d'état / statut
          </div>
        );
      case 'absent_b':
        return (
          <div className="flex items-center gap-1.5 text-xs font-semibold text-red-400 bg-red-950/50 border border-red-800/50 px-2.5 py-1 rounded-md whitespace-nowrap">
            <XCircle className="w-3.5 h-3.5" />
            Absent du Groupe B (Déficit)
          </div>
        );
      case 'absent_a':
        return (
          <div className="flex items-center gap-1.5 text-xs font-semibold text-cyan-400 bg-cyan-950/50 border border-cyan-800/50 px-2.5 py-1 rounded-md whitespace-nowrap">
            <Plus className="w-3.5 h-3.5" />
            Absent du Groupe A (Surplus)
          </div>
        );
      case 'doublon':
        return (
          <div className="flex items-center gap-1.5 text-xs font-semibold text-purple-400 bg-purple-950/50 border border-purple-800/50 px-2.5 py-1 rounded-md whitespace-nowrap">
            <Copy className="w-3.5 h-3.5" />
            Doublon interne
          </div>
        );
      case 'a_verifier':
        return (
          <div className="flex items-center gap-1.5 text-xs font-semibold text-yellow-300 bg-yellow-950/60 border border-yellow-700/60 px-2.5 py-1 rounded-md whitespace-nowrap">
            <HelpCircle className="w-3.5 h-3.5" />
            {isLocationMismatch ? 'Déplacement de bureau' : 'À vérifier'}
          </div>
        );
    }
  };

  // Quick resolution: User forces mark as resolved/conforme
  const handleResolvePair = (pair: MatchPair, newStatus: MatchStatus) => {
    onUpdatePair({
      ...pair,
      status: newStatus,
      statusLabel: newStatus === 'commun_conforme' ? 'Validé conforme par l\'auditeur' : pair.statusLabel,
      resolvedManually: true,
      manualNotes: manualNote || pair.manualNotes
    });
    setEditingPairId(null);
    setManualNote('');
  };

  return (
    <div className="space-y-4">
      {/* Filter Tabs Header */}
      <div className="flex flex-col gap-3 p-3.5 rounded-xl bg-[#0e111a] border border-[#212739]">
        <div className="flex items-center justify-between flex-wrap gap-2">
          {/* Segmented Controls for Status */}
          <div className="flex items-center gap-1 overflow-x-auto p-1 bg-[#121622] rounded-lg border border-[#252c3e] max-w-full">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
                activeFilter === 'all'
                  ? 'bg-gradient-to-r from-[#d4af37]/25 to-amber-500/20 text-amber-200 border border-[#d4af37]/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tous ({counts.all})
            </button>

            <button
              onClick={() => setActiveFilter('commun_conforme')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeFilter === 'commun_conforme'
                  ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-700/60'
                  : 'text-slate-400 hover:text-emerald-400'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Conformes ({counts.commun_conforme})
            </button>

            <button
              onClick={() => setActiveFilter('ecart_quantite')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeFilter === 'ecart_quantite'
                  ? 'bg-amber-950/70 text-amber-300 border border-amber-700/60'
                  : 'text-slate-400 hover:text-amber-400'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              Écarts Qté ({counts.ecart_quantite})
            </button>

            <button
              onClick={() => setActiveFilter('ecart_etat')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeFilter === 'ecart_etat'
                  ? 'bg-orange-950/70 text-orange-300 border border-orange-700/60'
                  : 'text-slate-400 hover:text-orange-400'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-orange-400" />
              Écarts État ({counts.ecart_etat})
            </button>

            <button
              onClick={() => setActiveFilter('absent_b')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeFilter === 'absent_b'
                  ? 'bg-red-950/70 text-red-300 border border-red-700/60'
                  : 'text-slate-400 hover:text-red-400'
              }`}
            >
              <XCircle className="w-3.5 h-3.5 text-red-400" />
              Manquants B ({counts.absent_b})
            </button>

            <button
              onClick={() => setActiveFilter('absent_a')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeFilter === 'absent_a'
                  ? 'bg-cyan-950/70 text-cyan-300 border border-cyan-700/60'
                  : 'text-slate-400 hover:text-cyan-400'
              }`}
            >
              <Plus className="w-3.5 h-3.5 text-cyan-400" />
              Surplus B ({counts.absent_a})
            </button>

            <button
              onClick={() => setActiveFilter('a_verifier')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeFilter === 'a_verifier'
                  ? 'bg-yellow-950/70 text-yellow-300 border border-yellow-700/60'
                  : 'text-slate-400 hover:text-yellow-400'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5 text-yellow-400" />
              À vérifier ({counts.a_verifier})
            </button>

            <button
              onClick={() => setActiveFilter('doublon')}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap flex items-center gap-1.5 ${
                activeFilter === 'doublon'
                  ? 'bg-purple-950/70 text-purple-300 border border-purple-700/60'
                  : 'text-slate-400 hover:text-purple-400'
              }`}
            >
              <Copy className="w-3.5 h-3.5 text-purple-400" />
              Doublons ({counts.doublon})
            </button>
          </div>
        </div>

        {/* Search and Location filter */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-[#1d2334]">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Filtrer la matrice (code, désignation, motif)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-[#121622] border border-[#272e42] rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#d4af37]"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <select
              value={selectedBureau}
              onChange={(e) => setSelectedBureau(e.target.value)}
              className="w-full sm:w-auto bg-[#121622] border border-[#272e42] rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#d4af37]"
            >
              <option value="ALL">Tous les emplacements ({bureauxList.length})</option>
              {bureauxList.map(b => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Reconciliation Table */}
      <div className="border border-[#202638] rounded-xl overflow-hidden bg-[#0a0d14] shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#121624] border-b border-[#21283c] text-slate-300 font-medium">
                <th className="py-3 px-3 w-40">Statut de Rapprochement</th>
                <th className="py-3 px-3 w-48">Emplacement Localisé</th>
                <th className="py-3 px-3 bg-[#131929]/70 border-r border-[#20273c]">
                  <div className="flex items-center gap-1.5 text-amber-300 font-semibold font-serif">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    Référence Groupe A (Comptable / Théorique)
                  </div>
                </th>
                <th className="py-3 px-3 bg-[#161e30]/70 border-r border-[#20273c]">
                  <div className="flex items-center gap-1.5 text-cyan-300 font-semibold font-serif">
                    <span className="w-2 h-2 rounded-full bg-cyan-400" />
                    Référence Groupe B (Recensement Terrain)
                  </div>
                </th>
                <th className="py-3 px-3 text-center w-24">Écart Qté</th>
                <th className="py-3 px-3 min-w-[200px]">Motif d'Écart & Analyse</th>
                <th className="py-3 px-2 text-center w-20">Résolution</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#181d2c]">
              {filteredPairs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    Aucun bien correspondant au filtre sélectionné.
                  </td>
                </tr>
              ) : (
                filteredPairs.map(pair => {
                  const itemA = pair.itemA;
                  const itemB = pair.itemB;
                  const isEditing = editingPairId === pair.id;

                  // Location presentation
                  const dir = itemA?.direction || itemB?.direction || '';
                  const bur = itemA?.bureau || itemB?.bureau || '';

                  return (
                    <tr 
                      key={pair.id}
                      className={`hover:bg-[#111522] transition-colors ${
                        pair.status === 'commun_conforme' 
                          ? 'bg-[#0b0e17]' 
                          : pair.status === 'a_verifier'
                          ? 'bg-[#181611]/30'
                          : 'bg-[#0d101a]'
                      }`}
                    >
                      {/* Status Column */}
                      <td className="py-3 px-3 align-top">
                        {renderStatusBadge(pair.status, pair.isLocationMismatch)}
                        <div className="mt-1 flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                          <span>Confiance :</span>
                          <span className={pair.confidence >= 90 ? 'text-emerald-400' : 'text-amber-400'}>
                            {pair.confidence}%
                          </span>
                        </div>
                        {pair.resolvedManually && (
                          <span className="mt-1 inline-block text-[9px] text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/50">
                            Validé manuellement
                          </span>
                        )}
                      </td>

                      {/* Location Column */}
                      <td className="py-3 px-3 align-top text-slate-300">
                        {bur ? (
                          <div className="font-medium text-slate-100 flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-[#d4af37] shrink-0" />
                            <span className="truncate max-w-[170px]" title={bur}>{bur}</span>
                          </div>
                        ) : (
                          <span className="text-slate-500 italic">— Non spécifié —</span>
                        )}
                        {dir && (
                          <div className="text-[11px] text-slate-400 truncate max-w-[170px] mt-0.5" title={dir}>
                            {dir}
                          </div>
                        )}
                      </td>

                      {/* Group A Card */}
                      <td className="py-3 px-3 align-top bg-[#121624]/40 border-r border-[#1e2436]">
                        {itemA ? (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="font-mono font-bold text-amber-300">
                                {itemA.code || <span className="text-slate-500 font-sans italic">— Sans code —</span>}
                              </span>
                              <span className="text-[11px] font-mono text-slate-300 bg-[#161b2a] px-1.5 py-0.5 rounded border border-[#2a3246]">
                                Qté : <strong className="text-amber-200">{itemA.quantite}</strong>
                              </span>
                            </div>
                            <p className="font-medium text-slate-100 leading-snug">
                              {itemA.designation}
                            </p>
                            <div className="flex items-center gap-2 text-[11px] text-slate-400">
                              <span>État : <strong className="text-slate-200 font-normal">{itemA.etat}</strong></span>
                              {itemA.date && (
                                <>
                                  <span>·</span>
                                  <span>{itemA.date}</span>
                                </>
                              )}
                            </div>
                          </div>
                        ) : (
                          <div className="py-2 text-slate-500 italic flex items-center gap-1.5">
                            <X className="w-3.5 h-3.5 text-slate-600" />
                            Non répertorié dans le Groupe A
                          </div>
                        )}
                      </td>

                      {/* Group B Card */}
                      <td className="py-3 px-3 align-top bg-[#131b2c]/40 border-r border-[#1e2436]">
                        {itemB ? (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="font-mono font-bold text-cyan-300">
                                {itemB.code || <span className="text-slate-500 font-sans italic">— Sans code —</span>}
                              </span>
                              <span className="text-[11px] font-mono text-slate-300 bg-[#161b2a] px-1.5 py-0.5 rounded border border-[#2a3246]">
                                Qté : <strong className="text-cyan-200">{itemB.quantite}</strong>
                              </span>
                            </div>
                            <p className="font-medium text-slate-100 leading-snug">
                              {itemB.designation}
                            </p>
                            <div className="flex items-center gap-2 text-[11px] text-slate-400">
                              <span>État : <strong className="text-slate-200 font-normal">{itemB.etat}</strong></span>
                              {itemB.bureau && itemA?.bureau && itemB.bureau !== itemA.bureau && (
                                <span className="text-amber-400 font-medium bg-amber-950/60 px-1 rounded border border-amber-800/60">
                                  Trouvé dans : {itemB.bureau}
                                </span>
                              )}
                            </div>
                          </div>
                        ) : (
                          <div className="py-2 text-slate-500 italic flex items-center gap-1.5">
                            <X className="w-3.5 h-3.5 text-slate-600" />
                            Non localisé lors du recensement B
                          </div>
                        )}
                      </td>

                      {/* Delta Column */}
                      <td className="py-3 px-3 align-top text-center font-mono">
                        {pair.quantiteDelta !== undefined && (pair.quantiteDelta !== 0 || pair.status === 'ecart_quantite') ? (
                          <span className={`px-2 py-0.5 rounded font-bold text-xs ${
                            pair.quantiteDelta > 0 
                              ? 'text-cyan-300 bg-cyan-950/50 border border-cyan-800/50' 
                              : 'text-red-300 bg-red-950/50 border border-red-800/50'
                          }`}>
                            {pair.quantiteDelta > 0 ? `+${pair.quantiteDelta}` : pair.quantiteDelta}
                          </span>
                        ) : (
                          <span className="text-emerald-400 font-medium">0 (Égal)</span>
                        )}
                      </td>

                      {/* Reason & Audit Note Column */}
                      <td className="py-3 px-3 align-top text-slate-300">
                        <p className="leading-relaxed">
                          {pair.matchReason}
                        </p>
                        {pair.manualNotes && (
                          <p className="mt-1 text-[11px] text-amber-300 bg-[#161a26] p-1.5 rounded border border-[#2d364c]">
                            <strong>Note d'audit :</strong> {pair.manualNotes}
                          </p>
                        )}
                      </td>

                      {/* Action Column */}
                      <td className="py-3 px-2 align-top text-center whitespace-nowrap">
                        {isEditing ? (
                          <div className="space-y-1">
                            <button
                              onClick={() => handleResolvePair(pair, 'commun_conforme')}
                              className="w-full py-1 px-1.5 text-[10px] font-semibold text-emerald-300 bg-emerald-950 hover:bg-emerald-900 border border-emerald-700 rounded transition-colors"
                            >
                              Valider conforme
                            </button>
                            <button
                              onClick={() => setEditingPairId(null)}
                              className="w-full py-1 px-1.5 text-[10px] text-slate-400 hover:text-slate-200"
                            >
                              Fermer
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setEditingPairId(pair.id)}
                            className="p-1.5 text-slate-400 hover:text-amber-300 rounded hover:bg-[#181d2c] transition-colors"
                            title="Arbitrer / modifier ce rapprochement"
                          >
                            <ArrowRightLeft className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Help helper for Lucide icons
function Plus(props: any) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <path d="M5 12h14" />
      <path d="M12 5v14" />
    </svg>
  );
}
