import React from 'react';
import { 
  Printer, 
  Download, 
  FileSpreadsheet, 
  FileText, 
  FileCheck, 
  X, 
  ShieldCheck, 
  Building2, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle,
  UserCheck
} from 'lucide-react';
import { MatchPair, ReconciliationSummary, CommissionInfo, InventoryItem } from '../types/inventory';
import { exportReconciliationToExcel, exportReconciliationToWord, exportReconciliationToPdf } from '../utils/exporters';

interface ReportPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  pairs: MatchPair[];
  summary: ReconciliationSummary;
  itemsA: InventoryItem[];
  itemsB: InventoryItem[];
  commissionA?: CommissionInfo;
  commissionB?: CommissionInfo;
  customIcon?: string;
}

export const ReportPreviewModal: React.FC<ReportPreviewModalProps> = ({
  isOpen,
  onClose,
  pairs,
  summary,
  itemsA,
  itemsB,
  commissionA,
  commissionB,
  customIcon
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-sm p-4 sm:p-6 lg:p-8 flex justify-center">
      <div className="bg-[#0b0e16] border border-[#273046] rounded-2xl w-full max-w-5xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Top Control Bar (Hidden in Print) */}
        <div className="no-print p-4 bg-[#111522] border-b border-[#21283c] flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="font-serif font-bold text-sm text-amber-300">
              Aperçu Officiel & Impression A4
            </span>
            <span className="text-[11px] text-slate-400">
              Procès-Verbal de Rapprochement Contradictoire
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-semibold text-slate-900 bg-gradient-to-r from-[#d4af37] to-amber-300 hover:from-amber-400 rounded-lg shadow transition-all flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              Imprimer Document A4
            </button>

            <button
              onClick={() => exportReconciliationToPdf(pairs, summary, commissionA, commissionB)}
              className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#171d2b] hover:bg-[#20283c] border border-[#2b354c] rounded-lg transition-colors flex items-center gap-1.5"
            >
              <FileCheck className="w-3.5 h-3.5 text-red-400" />
              PDF (.pdf)
            </button>

            <button
              onClick={() => exportReconciliationToWord(pairs, summary, commissionA, commissionB)}
              className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#171d2b] hover:bg-[#20283c] border border-[#2b354c] rounded-lg transition-colors flex items-center gap-1.5"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              Word (.docx)
            </button>

            <button
              onClick={() => exportReconciliationToExcel(pairs, summary, itemsA, itemsB, commissionA, commissionB)}
              className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#171d2b] hover:bg-[#20283c] border border-[#2b354c] rounded-lg transition-colors flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              Excel (.xlsx)
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-[#1a2030] ml-2"
              title="Fermer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Sheet View (Styled for A4 readability) */}
        <div className="overflow-y-auto p-6 sm:p-10 space-y-8 bg-[#0a0c13] text-slate-200 print:bg-white print:text-black">
          
          {/* Document Header */}
          <div className="border-b-2 border-[#d4af37]/60 pb-6 flex items-start justify-between gap-6">
            <div className="flex items-center gap-4">
              {customIcon ? (
                <img 
                  src={customIcon} 
                  alt="Logo d'audit" 
                  className="w-16 h-16 object-contain rounded-xl border border-[#d4af37]/40 p-1 bg-[#121622] print:bg-white" 
                />
              ) : (
                <div className="w-16 h-16 rounded-xl bg-[#131724] border border-[#d4af37]/50 flex items-center justify-center text-[#dfb743] shadow-md print:bg-gray-100">
                  <ShieldCheck className="w-8 h-8 text-[#d4af37]" />
                </div>
              )}
              <div>
                <h1 className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-gold-gradient print:text-black">
                  PROCÈS-VERBAL DE RAPPROCHEMENT D'INVENTAIRE
                </h1>
                <p className="text-xs text-slate-400 print:text-gray-600 mt-1">
                  Contrôle Contradictoire et Comparaison Physique A / B
                </p>
                <div className="flex items-center gap-3 text-[11px] text-slate-400 print:text-gray-500 mt-2">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-[#dfb743]" />
                    Date : {new Date().toLocaleDateString('fr-FR')}
                  </span>
                  <span>·</span>
                  <span>Réf : PV-CONF-AB-{Date.now().toString().slice(-6)}</span>
                  <span>·</span>
                  <span>Mode Hors-Ligne Sécurisé</span>
                </div>
              </div>
            </div>

            <div className="text-right text-xs">
              <span className="px-2.5 py-1 rounded bg-[#d4af37]/15 text-[#dfb743] border border-[#d4af37]/30 font-mono font-bold block print:border-black print:text-black">
                CONCORDANCE : {summary.tauxConcordance}%
              </span>
              <span className="text-[10px] text-slate-400 print:text-gray-500 mt-1 block">
                Identification : {summary.tauxIdentification}%
              </span>
            </div>
          </div>

          {/* Section 1: Commissions d'inventaire */}
          <div className="space-y-3">
            <h3 className="font-serif text-sm font-bold text-amber-300 print:text-black uppercase tracking-wider border-b border-[#21283c] pb-1">
              1. Composition des Commissions et Émargement
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-[#111420] rounded-lg border border-[#22283a] print:bg-gray-50 print:border-gray-300">
                <span className="font-bold text-amber-200 print:text-black block mb-1">
                  Commission Groupe A (Référentiel Initial)
                </span>
                <p className="text-slate-300 print:text-gray-800">
                  <strong>Président :</strong> {commissionA?.president || 'Inspecteur / Chef de mission désigné'}
                </p>
                <p className="text-slate-400 print:text-gray-600 mt-0.5">
                  <strong>Membres :</strong> {commissionA?.membres?.join(', ') || 'Comptable matières, Gestionnaire de patrimoine'}
                </p>
                {commissionA?.datePV && (
                  <p className="text-[11px] text-slate-400 print:text-gray-500 mt-1 italic">
                    {commissionA.datePV}
                  </p>
                )}
              </div>

              <div className="p-3 bg-[#111420] rounded-lg border border-[#22283a] print:bg-gray-50 print:border-gray-300">
                <span className="font-bold text-cyan-200 print:text-black block mb-1">
                  Commission Groupe B (Recensement Terrain)
                </span>
                <p className="text-slate-300 print:text-gray-800">
                  <strong>Président :</strong> {commissionB?.president || 'Auditeur / Chef d\'équipe de récolement'}
                </p>
                <p className="text-slate-400 print:text-gray-600 mt-0.5">
                  <strong>Membres :</strong> {commissionB?.membres?.join(', ') || 'Opérateurs de saisie, Agents de contrôle'}
                </p>
                {commissionB?.datePV && (
                  <p className="text-[11px] text-slate-400 print:text-gray-500 mt-1 italic">
                    {commissionB.datePV}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Section 2: Synthèse Chiffrée et Taux */}
          <div className="space-y-3">
            <h3 className="font-serif text-sm font-bold text-amber-300 print:text-black uppercase tracking-wider border-b border-[#21283c] pb-1">
              2. Synthèse Statistique et Taux de Concordance
            </h3>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-2.5 bg-[#111420] rounded-lg border border-[#22283a] print:bg-white print:border-gray-300">
                <span className="text-slate-400 print:text-gray-600 block">Total Rapproché</span>
                <span className="text-base font-bold font-mono text-slate-100 print:text-black">{summary.totalUniqueAssets} réf.</span>
              </div>
              <div className="p-2.5 bg-[#111420] rounded-lg border border-[#22283a] print:bg-white print:border-gray-300">
                <span className="text-slate-400 print:text-gray-600 block">Biens Conformes</span>
                <span className="text-base font-bold font-mono text-emerald-400 print:text-black">{summary.conformeCount} ({Math.round((summary.conformeCount / summary.totalUniqueAssets) * 100)}%)</span>
              </div>
              <div className="p-2.5 bg-[#111420] rounded-lg border border-[#22283a] print:bg-white print:border-gray-300">
                <span className="text-slate-400 print:text-gray-600 block">Écarts Quantité</span>
                <span className="text-base font-bold font-mono text-amber-400 print:text-black">{summary.ecartQuantiteCount} réf.</span>
              </div>
              <div className="p-2.5 bg-[#111420] rounded-lg border border-[#22283a] print:bg-white print:border-gray-300">
                <span className="text-slate-400 print:text-gray-600 block">Déficit / Non retrouvés</span>
                <span className="text-base font-bold font-mono text-red-400 print:text-black">{summary.absentBCount} réf.</span>
              </div>
            </div>

            <div className="p-3 bg-[#0d1018] rounded-lg border border-[#1f2537] text-xs text-slate-300 print:bg-gray-100 print:text-black">
              <strong>Méthodologie certifiée :</strong> {summary.methodologieCalcul}
            </div>
          </div>

          {/* Section 3: Causes et Recommandations */}
          <div className="space-y-3">
            <h3 className="font-serif text-sm font-bold text-amber-300 print:text-black uppercase tracking-wider border-b border-[#21283c] pb-1">
              3. Analyse des Écarts et Recommandations
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-2">
                <strong className="text-amber-200 print:text-black block">Causes probables identifiées :</strong>
                {summary.causesProbables.map((c, i) => (
                  <div key={i} className="p-2 rounded bg-[#10141f] border border-[#202738] print:border-gray-300 print:bg-white">
                    <span className="font-semibold text-slate-200 print:text-black">• {c.title} ({c.count} cas)</span>
                    <p className="text-[11px] text-slate-400 print:text-gray-600 mt-0.5">{c.description}</p>
                  </div>
                ))}
              </div>
              <div className="space-y-2">
                <strong className="text-amber-200 print:text-black block">Recommandations de l'audit :</strong>
                {summary.recommandations.map((r, i) => (
                  <div key={i} className="p-2 rounded bg-[#10141f] border border-[#202738] print:border-gray-300 print:bg-white">
                    <span className="text-slate-300 print:text-black">→ {r}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section 4: Matrice Détaillée */}
          <div className="space-y-3 page-break">
            <h3 className="font-serif text-sm font-bold text-amber-300 print:text-black uppercase tracking-wider border-b border-[#21283c] pb-1">
              4. Matrice Contradictoire Détaillée des Biens
            </h3>

            <table className="w-full text-left text-[11px] border-collapse border border-[#232a3d] print:border-gray-300">
              <thead>
                <tr className="bg-[#121622] text-slate-300 print:bg-gray-200 print:text-black font-semibold">
                  <th className="p-2 border border-[#232a3d] print:border-gray-300">Statut</th>
                  <th className="p-2 border border-[#232a3d] print:border-gray-300">Emplacement</th>
                  <th className="p-2 border border-[#232a3d] print:border-gray-300">Groupe A (Réf & Désignation)</th>
                  <th className="p-2 border border-[#232a3d] print:border-gray-300">Groupe B (Réf & Désignation)</th>
                  <th className="p-2 border border-[#232a3d] print:border-gray-300 text-center">Delta Qté</th>
                  <th className="p-2 border border-[#232a3d] print:border-gray-300">Motif de l'écart</th>
                </tr>
              </thead>
              <tbody>
                {pairs.map((p, idx) => (
                  <tr key={idx} className="border-b border-[#1b2131] print:border-gray-300">
                    <td className="p-2 font-medium border border-[#232a3d] print:border-gray-300">
                      {p.statusLabel}
                    </td>
                    <td className="p-2 border border-[#232a3d] print:border-gray-300">
                      {p.itemA?.bureau || p.itemB?.bureau || p.itemA?.direction || 'N/A'}
                    </td>
                    <td className="p-2 border border-[#232a3d] print:border-gray-300">
                      {p.itemA ? `[${p.itemA.code || 'S/C'}] ${p.itemA.designation} (Qté: ${p.itemA.quantite}, État: ${p.itemA.etat})` : '— Absent —'}
                    </td>
                    <td className="p-2 border border-[#232a3d] print:border-gray-300">
                      {p.itemB ? `[${p.itemB.code || 'S/C'}] ${p.itemB.designation} (Qté: ${p.itemB.quantite}, État: ${p.itemB.etat})` : '— Absent —'}
                    </td>
                    <td className="p-2 text-center font-mono font-bold border border-[#232a3d] print:border-gray-300">
                      {p.quantiteDelta !== undefined && p.quantiteDelta !== 0 
                        ? (p.quantiteDelta > 0 ? `+${p.quantiteDelta}` : p.quantiteDelta) 
                        : '0'}
                    </td>
                    <td className="p-2 text-slate-400 print:text-gray-700 border border-[#232a3d] print:border-gray-300">
                      {p.matchReason}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Section 5: Signature Blocks */}
          <div className="pt-8 border-t-2 border-[#d4af37]/40 space-y-8">
            <div className="text-xs text-slate-300 print:text-gray-800 text-right">
              Fait pour valoir et servir ce que de droit, le {new Date().toLocaleDateString('fr-FR')}.
            </div>
            
            <div className="grid grid-cols-2 gap-8 pt-4">
              <div className="p-4 border border-[#262e42] rounded-xl text-center print:border-gray-400 h-32 flex flex-col justify-between">
                <span className="text-xs font-bold text-slate-300 print:text-black">
                  Pour la Commission Groupe A<br />(Signature & Cachet)
                </span>
                <span className="text-[10px] text-slate-500 italic">
                  {commissionA?.president || 'Le Président de Commission'}
                </span>
              </div>

              <div className="p-4 border border-[#262e42] rounded-xl text-center print:border-gray-400 h-32 flex flex-col justify-between">
                <span className="text-xs font-bold text-slate-300 print:text-black">
                  Pour la Commission Groupe B<br />(Signature & Cachet)
                </span>
                <span className="text-[10px] text-slate-500 italic">
                  {commissionB?.president || 'L\'Auditeur Terrain Indépendant'}
                </span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
