import React, { useState } from 'react';
import { 
  Percent, 
  HelpCircle, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  FileText, 
  ShieldAlert, 
  ArrowUpRight, 
  Compass, 
  ClipboardCheck, 
  Info, 
  Building2,
  FileCheck
} from 'lucide-react';
import { ReconciliationSummary } from '../types/inventory';

interface AnalyticsSummaryProps {
  summary: ReconciliationSummary;
}

export const AnalyticsSummary: React.FC<AnalyticsSummaryProps> = ({ summary }) => {
  const [showFormulaDetails, setShowFormulaDetails] = useState(false);

  const total = summary.totalUniqueAssets || 1;
  const pctConforme = Math.round((summary.conformeCount / total) * 100);
  const pctQty = Math.round((summary.ecartQuantiteCount / total) * 100);
  const pctState = Math.round((summary.ecartEtatCount / total) * 100);
  const pctAbsentB = Math.round((summary.absentBCount / total) * 100);
  const pctAbsentA = Math.round((summary.absentACount / total) * 100);
  const pctCheck = Math.round((summary.aVerifierCount / total) * 100);
  const pctDup = Math.round((summary.doublonCount / total) * 100);

  return (
    <div className="space-y-5">
      {/* Top 4 Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Strict Concordance Rate */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-[#121624] via-[#0f121d] to-[#0a0d14] border border-[#d4af37]/40 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#d4af37]/5 rounded-bl-full pointer-events-none" />
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="flex items-center gap-1.5 font-medium text-amber-200">
              <Percent className="w-3.5 h-3.5 text-[#dfb743]" />
              Taux de Concordance Strict
            </span>
            <button
              onClick={() => setShowFormulaDetails(!showFormulaDetails)}
              className="text-[#d4af37] hover:underline flex items-center gap-0.5 text-[10px]"
              title="Voir la formule mathématique"
            >
              <Info className="w-3 h-3" />
              Méthode
            </button>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-extrabold font-mono text-gold-gradient tracking-tight">
              {summary.tauxConcordance}%
            </span>
            <span className="text-xs text-slate-400">
              ({summary.conformeCount}/{summary.totalUniqueAssets} conformes)
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Biens rigoureusement identiques en quantité, état d'usage et emplacement.
          </p>
        </div>

        {/* Card 2: Identification Rate */}
        <div className="p-4 rounded-xl bg-[#0f121b] border border-[#23293a] shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="flex items-center gap-1.5 font-medium text-cyan-300">
              <ClipboardCheck className="w-3.5 h-3.5 text-cyan-400" />
              Taux d'Identification
            </span>
            <span className="text-[10px] font-mono text-slate-400">Global</span>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-extrabold font-mono text-cyan-400 tracking-tight">
              {summary.tauxIdentification}%
            </span>
            <span className="text-xs text-slate-400">
              du Groupe A localisé
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Proportion de biens répertoriés retrouvés physiquement sur le terrain.
          </p>
        </div>

        {/* Card 3: Discrepancy Volume */}
        <div className="p-4 rounded-xl bg-[#0f121b] border border-[#23293a] shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="flex items-center gap-1.5 font-medium text-amber-300">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              Total Biens en Écart
            </span>
            <span className="text-[10px] font-mono text-red-400">
              {summary.totalUniqueAssets - summary.conformeCount} réf.
            </span>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-extrabold font-mono text-slate-100 tracking-tight">
              {summary.ecartQuantiteCount + summary.ecartEtatCount + summary.absentBCount + summary.absentACount}
            </span>
            <span className="text-xs text-slate-400">
              anomalies nettes
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            {summary.absentBCount} manquants · {summary.absentACount} surplus · {summary.ecartQuantiteCount} écarts qté
          </p>
        </div>

        {/* Card 4: Physical Unit Quantities A vs B */}
        <div className="p-4 rounded-xl bg-[#0f121b] border border-[#23293a] shadow-lg">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="flex items-center gap-1.5 font-medium text-slate-300">
              <TrendingUp className="w-3.5 h-3.5 text-[#d4af37]" />
              Unités Physiques Constatées
            </span>
            <span className="text-[10px] font-mono text-slate-400">Delta</span>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-2xl font-extrabold font-mono text-amber-300 tracking-tight">
              {summary.totalQuantiteA}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              vs <strong className="text-cyan-300">{summary.totalQuantiteB}</strong>
            </span>
            <span className={`text-xs font-mono font-bold ml-auto px-1.5 py-0.5 rounded ${
              summary.totalQuantiteB - summary.totalQuantiteA >= 0
                ? 'text-cyan-400 bg-cyan-950/60'
                : 'text-red-400 bg-red-950/60'
            }`}>
              {summary.totalQuantiteB - summary.totalQuantiteA >= 0 ? '+' : ''}
              {summary.totalQuantiteB - summary.totalQuantiteA}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Groupe A : {summary.totalItemsA} lignes · Groupe B : {summary.totalItemsB} lignes
          </p>
        </div>

      </div>

      {/* Mathematical Methodology Box */}
      {showFormulaDetails && (
        <div className="p-4 rounded-xl bg-[#111420] border border-[#d4af37]/50 shadow-xl space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-[#212739]">
            <h4 className="font-serif text-xs font-bold text-amber-300 flex items-center gap-2">
              <Info className="w-4 h-4 text-[#dfb743]" />
              Formule Mathématique et Méthode de Calcul Certifiée
            </h4>
            <button 
              onClick={() => setShowFormulaDetails(false)}
              className="text-slate-400 hover:text-slate-200 text-xs"
            >
              Fermer
            </button>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed font-mono bg-[#090b10] p-2.5 rounded border border-[#222736]">
            {summary.methodologieCalcul}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-400 pt-2">
            <div>
              <strong className="text-slate-200 block mb-0.5">1. Critère de Concordance Stricte :</strong>
              Le bien doit être présent dans les deux inventaires avec le même code d'inventaire (ou désignation exacte), au sein du même bureau, avec une quantité physique rigoureusement identique et un état physique équivalent.
            </div>
            <div>
              <strong className="text-slate-200 block mb-0.5">2. Règle d'Impartialité :</strong>
              Aucun appariement arbitraire n'est forcé. Les similarités partielles (65%–84%) et les biens trouvés dans un autre bureau sont classés « À vérifier » pour arbitrage de la commission.
            </div>
          </div>
        </div>
      )}

      {/* Visual Proportion Breakdown Bar */}
      <div className="p-4 rounded-xl bg-[#0e111a] border border-[#202638] space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-serif font-bold text-slate-200">
            Répartition Proportionnelle des Biens Rapprochés ({summary.totalUniqueAssets} références)
          </span>
          <span className="text-slate-400 font-mono text-[11px]">
            Concordance : <strong className="text-emerald-400">{pctConforme}%</strong>
          </span>
        </div>

        {/* Stacked Progress Bar */}
        <div className="h-3 w-full bg-[#141824] rounded-full overflow-hidden flex shadow-inner">
          <div style={{ width: `${pctConforme}%` }} className="bg-emerald-500 hover:opacity-90 transition-all" title={`Conformes: ${pctConforme}%`} />
          <div style={{ width: `${pctQty}%` }} className="bg-amber-500 hover:opacity-90 transition-all" title={`Écart qté: ${pctQty}%`} />
          <div style={{ width: `${pctState}%` }} className="bg-orange-500 hover:opacity-90 transition-all" title={`Écart état: ${pctState}%`} />
          <div style={{ width: `${pctAbsentB}%` }} className="bg-red-500 hover:opacity-90 transition-all" title={`Absent B (Déficit): ${pctAbsentB}%`} />
          <div style={{ width: `${pctAbsentA}%` }} className="bg-cyan-500 hover:opacity-90 transition-all" title={`Absent A (Surplus): ${pctAbsentA}%`} />
          <div style={{ width: `${pctCheck}%` }} className="bg-yellow-400 hover:opacity-90 transition-all" title={`À vérifier: ${pctCheck}%`} />
          <div style={{ width: `${pctDup}%` }} className="bg-purple-500 hover:opacity-90 transition-all" title={`Doublons: ${pctDup}%`} />
        </div>

        {/* Legend */}
        <div className="flex items-center flex-wrap gap-x-4 gap-y-2 text-[11px] text-slate-400 pt-1">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            Conformes : <strong className="text-slate-200">{summary.conformeCount} ({pctConforme}%)</strong>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            Écart qté : <strong className="text-slate-200">{summary.ecartQuantiteCount} ({pctQty}%)</strong>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500" />
            Écart état : <strong className="text-slate-200">{summary.ecartEtatCount} ({pctState}%)</strong>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
            Déficit B : <strong className="text-slate-200">{summary.absentBCount} ({pctAbsentB}%)</strong>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
            Surplus B : <strong className="text-slate-200">{summary.absentACount} ({pctAbsentA}%)</strong>
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
            À vérifier : <strong className="text-slate-200">{summary.aVerifierCount} ({pctCheck}%)</strong>
          </span>
          {summary.doublonCount > 0 && (
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
              Doublons : <strong className="text-slate-200">{summary.doublonCount} ({pctDup}%)</strong>
            </span>
          )}
        </div>
      </div>

      {/* Probable Causes & Recommendations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Causes Probables Card */}
        <div className="p-4 rounded-xl bg-[#0e111a] border border-[#202638] space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-[#1f2638]">
            <ShieldAlert className="w-4 h-4 text-[#dfb743]" />
            <h3 className="font-serif text-sm font-bold text-slate-100">
              Causes Probables Identifiées ({summary.causesProbables.length})
            </h3>
          </div>

          <div className="space-y-2.5">
            {summary.causesProbables.length === 0 ? (
              <p className="text-xs text-slate-500 italic py-4 text-center">
                Aucune anomalie critique détectée. Tous les biens sont conformes.
              </p>
            ) : (
              summary.causesProbables.map((cause, idx) => (
                <div key={idx} className="p-3 rounded-lg bg-[#121622] border border-[#21283c] space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-xs text-amber-200">
                      {cause.title}
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#1c2233] text-[#dfb743] border border-[#313c54]">
                      {cause.count} cas
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    {cause.description}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recommandations Card */}
        <div className="p-4 rounded-xl bg-[#0e111a] border border-[#202638] space-y-3">
          <div className="flex items-center gap-2 pb-2 border-b border-[#1f2638]">
            <Compass className="w-4 h-4 text-[#dfb743]" />
            <h3 className="font-serif text-sm font-bold text-slate-100">
              Recommandations Stratégiques d'Audit
            </h3>
          </div>

          <div className="space-y-2.5">
            {summary.recommandations.map((rec, idx) => (
              <div key={idx} className="p-3 rounded-lg bg-[#121622] border border-[#21283c] flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-[#d4af37]/15 text-[#dfb743] font-mono font-bold text-[10px] flex items-center justify-center shrink-0 border border-[#d4af37]/30 mt-0.5">
                  0{idx + 1}
                </span>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {rec}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
