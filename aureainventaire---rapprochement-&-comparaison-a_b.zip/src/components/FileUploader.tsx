import React, { useState, useRef } from 'react';
import { 
  UploadCloud, 
  FileText, 
  FileSpreadsheet, 
  FileCheck, 
  CheckCircle, 
  AlertTriangle, 
  Scan, 
  Users, 
  Building2, 
  Trash2, 
  Eye, 
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { InventoryItem, CommissionInfo } from '../types/inventory';
import { parseExcelFile, parseWordFile, parsePdfFile, runOcrOnScannedPdf } from '../utils/fileParsers';

interface FileUploaderProps {
  groupName: 'Groupe A' | 'Groupe B';
  groupSubtitle: string;
  items: InventoryItem[];
  commission: CommissionInfo;
  fileName?: string;
  onDataLoaded: (items: InventoryItem[], commission: CommissionInfo, fileName: string, fileType: string) => void;
  onClear: () => void;
  onViewItems: () => void;
}

export const FileUploader: React.FC<FileUploaderProps> = ({
  groupName,
  groupSubtitle,
  items,
  commission,
  fileName,
  onDataLoaded,
  onClear,
  onViewItems
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [isScannedPdf, setIsScannedPdf] = useState(false);
  const [currentFile, setCurrentFile] = useState<File | null>(null);
  const [ocrProgress, setOcrProgress] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = async (file: File) => {
    setIsLoading(true);
    setCurrentFile(file);
    setIsScannedPdf(false);
    setLoadingMessage(`Lecture locale de ${file.name}...`);

    try {
      const ext = file.name.split('.').pop()?.toLowerCase() || '';

      if (['xlsx', 'xls', 'csv'].includes(ext)) {
        const res = await parseExcelFile(file);
        onDataLoaded(res.items, res.commission, file.name, 'Excel');
      } else if (['docx', 'doc'].includes(ext)) {
        const res = await parseWordFile(file);
        onDataLoaded(res.items, res.commission, file.name, 'Word');
      } else if (ext === 'pdf') {
        const res = await parsePdfFile(file, (p, tot, msg) => {
          setLoadingMessage(msg);
        });

        if (res.isScanned || res.items.length === 0) {
          setIsScannedPdf(true);
        }
        onDataLoaded(res.items, res.commission, file.name, 'PDF');
      } else {
        alert("Format non supporté. Veuillez importer un fichier Excel (.xlsx, .xls), Word (.docx) ou PDF (.pdf).");
      }
    } catch (err: any) {
      console.error("Error processing file:", err);
      alert(`Erreur lors du traitement du fichier : ${err.message || 'Format illisible'}`);
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleLaunchOcr = async () => {
    if (!currentFile) return;
    setIsLoading(true);
    setOcrProgress(5);
    try {
      const res = await runOcrOnScannedPdf(currentFile, (pct, msg) => {
        setOcrProgress(pct);
        setLoadingMessage(msg);
      });
      onDataLoaded(res.items, res.commission, currentFile.name + ' (OCR)', 'PDF Scanné');
      setIsScannedPdf(false);
    } catch (err: any) {
      console.error("OCR failed:", err);
      alert(`Échec de la reconnaissance OCR : ${err.message}`);
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
      setOcrProgress(0);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => {
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  };

  const onFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  // Unique directions & bureaux
  const directions = Array.from(new Set(items.map(i => i.direction).filter(Boolean)));
  const bureaux = Array.from(new Set(items.map(i => i.bureau).filter(Boolean)));
  const totalQté = items.reduce((sum, i) => sum + (Number(i.quantite) || 0), 0);

  return (
    <div className="bg-[#0e111a] border border-[#23293a] rounded-2xl p-5 shadow-lg relative overflow-hidden flex flex-col justify-between h-full">
      {/* Top Header */}
      <div>
        <div className="flex items-center justify-between pb-3 border-b border-[#202636]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#d4af37]/10 border border-[#d4af37]/30 flex items-center justify-center text-[#dfb743] font-semibold text-xs font-mono">
              {groupName === 'Groupe A' ? 'A' : 'B'}
            </div>
            <div>
              <h3 className="font-serif text-base font-bold text-slate-100 flex items-center gap-2">
                {groupName}
                {items.length > 0 && (
                  <span className="text-xs font-sans font-normal text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" />
                    Chargé ({items.length})
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">{groupSubtitle}</p>
            </div>
          </div>

          {items.length > 0 && (
            <div className="flex items-center gap-1.5">
              <button
                onClick={onViewItems}
                className="px-2.5 py-1 text-xs font-medium text-amber-200 hover:text-amber-100 bg-[#161c2b] hover:bg-[#1f283d] border border-[#d4af37]/30 rounded-md transition-colors flex items-center gap-1"
                title="Vérifier et corriger les données extraites"
              >
                <Eye className="w-3 h-3 text-[#d4af37]" />
                Vérifier
              </button>
              <button
                onClick={onClear}
                className="p-1 text-slate-400 hover:text-red-400 transition-colors rounded hover:bg-[#1b1f2b]"
                title="Retirer ce fichier"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Loading Spinner */}
        {isLoading && (
          <div className="my-6 p-6 rounded-xl bg-[#131722] border border-[#d4af37]/30 text-center space-y-3">
            <RefreshCw className="w-8 h-8 text-[#dfb743] animate-spin mx-auto" />
            <p className="text-sm font-medium text-amber-200">{loadingMessage}</p>
            {ocrProgress > 0 && (
              <div className="w-full max-w-xs mx-auto bg-[#0a0c12] rounded-full h-2 overflow-hidden border border-[#2a3144]">
                <div 
                  className="bg-gradient-to-r from-[#d4af37] to-amber-300 h-full transition-all duration-300" 
                  style={{ width: `${ocrProgress}%` }}
                />
              </div>
            )}
          </div>
        )}

        {/* Empty state: Dropzone */}
        {!isLoading && items.length === 0 && (
          <div
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            onDrop={onDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`my-4 border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
              isDragging
                ? 'border-[#d4af37] bg-[#d4af37]/10'
                : 'border-[#293044] hover:border-[#d4af37]/60 hover:bg-[#121624]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv,.docx,.doc,.pdf"
              className="hidden"
              onChange={onFileSelect}
            />
            <div className="w-12 h-12 rounded-xl bg-[#161a26] border border-[#2e374d] flex items-center justify-center mx-auto mb-3 text-[#d4af37]">
              <UploadCloud className="w-6 h-6" />
            </div>
            <p className="text-sm font-medium text-slate-200">
              Glissez-déposez le fichier du {groupName}
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Formats acceptés : <strong className="text-amber-200/80 font-normal">Excel (.xlsx, .xls), Word (.docx), PDF</strong>
            </p>
            <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-[#d4af37] bg-[#d4af37]/10 border border-[#d4af37]/30 hover:bg-[#d4af37]/20 transition-all">
              <Sparkles className="w-3 h-3" />
              Parcourir mes fichiers locaux
            </div>
          </div>
        )}

        {/* Scanned PDF Alert & OCR Trigger */}
        {isScannedPdf && !isLoading && (
          <div className="my-3 p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/40 space-y-2">
            <div className="flex items-start gap-2.5">
              <Scan className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs text-amber-200">
                <span className="font-semibold block text-amber-300">Document PDF scanné détecté</span>
                Ce document semble être un scan sans texte numérique. Vous pouvez activer l'OCR local pour extraire les tableaux et lignes d'inventaire.
              </div>
            </div>
            <button
              onClick={handleLaunchOcr}
              className="w-full mt-2 py-2 px-3 text-xs font-semibold text-slate-950 bg-gradient-to-r from-[#d4af37] to-amber-300 hover:from-amber-400 hover:to-amber-200 rounded-lg shadow transition-all flex items-center justify-center gap-2"
            >
              <Scan className="w-3.5 h-3.5" />
              Lancer la Reconnaissance OCR Locale (Tesseract)
            </button>
          </div>
        )}

        {/* Populated State Details */}
        {!isLoading && items.length > 0 && (
          <div className="my-4 space-y-3">
            <div className="p-3 bg-[#131722] rounded-xl border border-[#252c3d] flex items-center justify-between">
              <div className="flex items-center gap-2 truncate">
                <FileSpreadsheet className="w-4 h-4 text-[#d4af37] shrink-0" />
                <span className="text-xs font-medium text-slate-200 truncate" title={fileName}>
                  {fileName}
                </span>
              </div>
              <span className="text-[11px] font-mono text-[#d4af37] bg-[#d4af37]/10 px-2 py-0.5 rounded border border-[#d4af37]/30 shrink-0">
                {items.length} lignes ({totalQté} unités)
              </span>
            </div>

            {/* Structure extracted */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 bg-[#10141f] rounded-lg border border-[#202738]">
                <div className="text-slate-400 flex items-center gap-1 mb-1">
                  <Building2 className="w-3 h-3 text-amber-400" />
                  Directions repérées
                </div>
                <div className="font-semibold text-slate-200 truncate">
                  {directions.length > 0 ? `${directions.length} direction(s)` : 'Non spécifiée'}
                </div>
                {directions.length > 0 && (
                  <p className="text-[10px] text-slate-400 truncate mt-0.5" title={directions.join(', ')}>
                    {directions[0]} {directions.length > 1 ? `+${directions.length - 1}` : ''}
                  </p>
                )}
              </div>

              <div className="p-2.5 bg-[#10141f] rounded-lg border border-[#202738]">
                <div className="text-slate-400 flex items-center gap-1 mb-1">
                  <Building2 className="w-3 h-3 text-amber-400" />
                  Bureaux / Locaux
                </div>
                <div className="font-semibold text-slate-200">
                  {bureaux.length > 0 ? `${bureaux.length} bureau(x)` : 'Non spécifiés'}
                </div>
                {bureaux.length > 0 && (
                  <p className="text-[10px] text-slate-400 truncate mt-0.5" title={bureaux.join(', ')}>
                    {bureaux[0]} {bureaux.length > 1 ? `+${bureaux.length - 1}` : ''}
                  </p>
                )}
              </div>
            </div>

            {/* Commission members detected (Excluded from items) */}
            {commission.detected && (
              <div className="p-2.5 bg-[#121620] rounded-lg border border-[#2e374e]">
                <div className="flex items-center gap-1.5 text-xs text-amber-300 mb-1">
                  <Users className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span className="font-semibold">Commission d'inventaire isolée</span>
                  <span className="text-[10px] text-slate-400 font-mono">(Exclue du comparatif)</span>
                </div>
                {commission.president && (
                  <p className="text-[11px] text-slate-300 truncate">
                    <strong className="text-amber-200/90 font-medium">Président :</strong> {commission.president}
                  </p>
                )}
                {commission.membres.length > 0 && (
                  <p className="text-[11px] text-slate-400 truncate">
                    <strong className="text-slate-300 font-medium">Membres :</strong> {commission.membres.join(', ')}
                  </p>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Action Footer */}
      {items.length > 0 && (
        <div className="pt-3 border-t border-[#1d2332] flex items-center justify-between">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="text-[11px] text-slate-400 hover:text-amber-300 transition-colors flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            Remplacer le fichier
          </button>
          <button
            onClick={onViewItems}
            className="text-[11px] text-[#d4af37] hover:underline flex items-center gap-1 font-medium"
          >
            Voir les {items.length} biens extraits →
          </button>
        </div>
      )}
    </div>
  );
};
