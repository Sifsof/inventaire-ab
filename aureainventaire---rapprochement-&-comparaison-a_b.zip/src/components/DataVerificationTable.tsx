import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  X, 
  Download, 
  FileSpreadsheet, 
  Building2, 
  MapPin, 
  CheckCircle2, 
  AlertCircle,
  ArrowUpDown,
  Layers
} from 'lucide-react';
import { InventoryItem } from '../types/inventory';
import { exportSingleGroupToExcel } from '../utils/exporters';

interface DataVerificationTableProps {
  groupTitle: 'Groupe A' | 'Groupe B';
  items: InventoryItem[];
  onUpdateItems: (updated: InventoryItem[]) => void;
  onBackToComparison: () => void;
}

export const DataVerificationTable: React.FC<DataVerificationTableProps> = ({
  groupTitle,
  items,
  onUpdateItems,
  onBackToComparison
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDirection, setSelectedDirection] = useState('ALL');
  const [selectedBureau, setSelectedBureau] = useState('ALL');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<InventoryItem | null>(null);
  const [selectedItemIds, setSelectedItemIds] = useState<Set<string>>(new Set());

  // Bulk assign state
  const [bulkDirection, setBulkDirection] = useState('');
  const [bulkBureau, setBulkBureau] = useState('');
  const [showBulkModal, setShowBulkModal] = useState(false);

  // Filter options
  const directions = useMemo(() => {
    return Array.from(new Set(items.map(i => i.direction).filter(Boolean))).sort();
  }, [items]);

  const bureaux = useMemo(() => {
    return Array.from(new Set(items.map(i => i.bureau).filter(Boolean))).sort();
  }, [items]);

  // Filtered items
  const filteredItems = useMemo(() => {
    return items.filter(item => {
      const matchSearch = searchTerm === '' || 
        item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.designation.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.direction.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.bureau.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.observations.toLowerCase().includes(searchTerm.toLowerCase());

      const matchDir = selectedDirection === 'ALL' || item.direction === selectedDirection;
      const matchBur = selectedBureau === 'ALL' || item.bureau === selectedBureau;

      return matchSearch && matchDir && matchBur;
    });
  }, [items, searchTerm, selectedDirection, selectedBureau]);

  const totalQuantity = items.reduce((acc, curr) => acc + (Number(curr.quantite) || 0), 0);

  // Edit item handlers
  const startEditing = (item: InventoryItem) => {
    setEditingId(item.id);
    setEditFormData({ ...item });
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditFormData(null);
  };

  const saveEditing = () => {
    if (!editFormData) return;
    const updated = items.map(i => (i.id === editFormData.id ? editFormData : i));
    onUpdateItems(updated);
    setEditingId(null);
    setEditFormData(null);
  };

  const handleEditChange = (field: keyof InventoryItem, value: any) => {
    if (!editFormData) return;
    setEditFormData({ ...editFormData, [field]: value });
  };

  // Add new row
  const addNewItem = () => {
    const newItem: InventoryItem = {
      id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      direction: selectedDirection !== 'ALL' ? selectedDirection : (directions[0] || ''),
      bureau: selectedBureau !== 'ALL' ? selectedBureau : (bureaux[0] || ''),
      code: `INV-${Date.now().toString().slice(-4)}`,
      designation: 'Nouveau bien d\'inventaire',
      quantite: 1,
      etat: 'Bon',
      date: new Date().toLocaleDateString('fr-FR'),
      bloc: '',
      observations: ''
    };
    onUpdateItems([newItem, ...items]);
    startEditing(newItem);
  };

  // Delete single item
  const deleteItem = (id: string) => {
    if (confirm("Confirmer la suppression de cette ligne d'inventaire ?")) {
      const updated = items.filter(i => i.id !== id);
      onUpdateItems(updated);
      if (selectedItemIds.has(id)) {
        const next = new Set(selectedItemIds);
        next.delete(id);
        setSelectedItemIds(next);
      }
    }
  };

  // Selection toggle
  const toggleSelectAll = () => {
    if (selectedItemIds.size === filteredItems.length) {
      setSelectedItemIds(new Set());
    } else {
      setSelectedItemIds(new Set(filteredItems.map(i => i.id)));
    }
  };

  const toggleSelectOne = (id: string) => {
    const next = new Set(selectedItemIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedItemIds(next);
  };

  // Bulk Apply Direction / Bureau
  const applyBulkChanges = () => {
    if (selectedItemIds.size === 0) return;
    const updated = items.map(item => {
      if (selectedItemIds.has(item.id)) {
        return {
          ...item,
          direction: bulkDirection.trim() ? bulkDirection.trim() : item.direction,
          bureau: bulkBureau.trim() ? bulkBureau.trim() : item.bureau
        };
      }
      return item;
    });
    onUpdateItems(updated);
    setShowBulkModal(false);
    setBulkDirection('');
    setBulkBureau('');
    setSelectedItemIds(new Set());
  };

  return (
    <div className="space-y-4">
      {/* Top Banner and Actions */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-4 rounded-xl bg-[#0f121b] border border-[#23293b]">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-[#d4af37]/15 text-[#dfb743] border border-[#d4af37]/30">
              {groupTitle}
            </span>
            <h2 className="text-lg font-serif font-bold text-slate-100">
              Vérification et Contrôle des Données Extraites
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Reconstitution de la hiérarchie direction/bureau. Vérifiez, modifiez ou complétez les champs avant comparaison.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => exportSingleGroupToExcel(items, groupTitle === 'Groupe A' ? 'Groupe_A' : 'Groupe_B')}
            className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#161a27] hover:bg-[#1e2436] border border-[#2b3347] rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-[#d4af37]" />
            Exporter {groupTitle} (.xlsx)
          </button>

          <button
            onClick={addNewItem}
            className="px-3 py-1.5 text-xs font-medium text-slate-900 bg-gradient-to-r from-[#d4af37] to-amber-300 hover:from-amber-400 hover:to-amber-200 rounded-lg shadow transition-all flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            Ajouter un bien
          </button>

          <button
            onClick={onBackToComparison}
            className="px-3 py-1.5 text-xs font-medium text-amber-200 bg-[#1a1f2e] hover:bg-[#232a3f] border border-[#d4af37]/40 rounded-lg transition-all flex items-center gap-1.5"
          >
            <Layers className="w-3.5 h-3.5 text-[#d4af37]" />
            Retour à la Comparaison A/B
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 rounded-lg bg-[#0e111a] border border-[#1f2535]">
          <span className="text-[11px] text-slate-400 block">Total Références</span>
          <span className="text-lg font-bold font-mono text-slate-100">{items.length}</span>
        </div>
        <div className="p-3 rounded-lg bg-[#0e111a] border border-[#1f2535]">
          <span className="text-[11px] text-slate-400 block">Quantité Totale Physique</span>
          <span className="text-lg font-bold font-mono text-[#dfb743]">{totalQuantity}</span>
        </div>
        <div className="p-3 rounded-lg bg-[#0e111a] border border-[#1f2535]">
          <span className="text-[11px] text-slate-400 block">Directions Identifiées</span>
          <span className="text-lg font-bold font-mono text-slate-100">{directions.length}</span>
        </div>
        <div className="p-3 rounded-lg bg-[#0e111a] border border-[#1f2535]">
          <span className="text-[11px] text-slate-400 block">Bureaux / Locaux</span>
          <span className="text-lg font-bold font-mono text-slate-100">{bureaux.length}</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3 rounded-xl bg-[#0e111a] border border-[#1e2434] flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Rechercher par code, libellé, bureau..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-[#121622] border border-[#272e42] rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-[#d4af37]"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          {/* Direction Filter */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <Building2 className="w-3.5 h-3.5 text-amber-400" />
            <select
              value={selectedDirection}
              onChange={(e) => setSelectedDirection(e.target.value)}
              className="bg-[#121622] border border-[#272e42] rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#d4af37]"
            >
              <option value="ALL">Toutes les directions ({directions.length})</option>
              {directions.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          {/* Bureau Filter */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <MapPin className="w-3.5 h-3.5 text-amber-400" />
            <select
              value={selectedBureau}
              onChange={(e) => setSelectedBureau(e.target.value)}
              className="bg-[#121622] border border-[#272e42] rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-[#d4af37]"
            >
              <option value="ALL">Tous les bureaux ({bureaux.length})</option>
              {bureaux.map(b => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </div>

          {/* Bulk actions button */}
          {selectedItemIds.size > 0 && (
            <button
              onClick={() => setShowBulkModal(true)}
              className="px-2.5 py-1.5 text-xs font-medium text-amber-300 bg-[#192030] border border-[#d4af37]/40 rounded-lg hover:bg-[#20293d] transition-colors"
            >
              Affecter l'emplacement ({selectedItemIds.size})
            </button>
          )}
        </div>
      </div>

      {/* Bulk Assign Modal */}
      {showBulkModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-[#10141f] border border-[#d4af37]/40 rounded-xl p-5 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-[#212738]">
              <h3 className="font-serif text-sm font-bold text-amber-300">
                Affectation en Masse ({selectedItemIds.size} ligne(s) sélectionnée(s))
              </h3>
              <button onClick={() => setShowBulkModal(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-400">
              Rattachez directement les lignes sélectionnées à une direction et/ou un bureau. Les champs laissés vides ne seront pas modifiés.
            </p>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Direction / Service</label>
                <input
                  type="text"
                  placeholder="Ex: DIRECTION DES SYSTÈMES D'INFORMATION"
                  value={bulkDirection}
                  onChange={(e) => setBulkDirection(e.target.value)}
                  className="w-full px-3 py-2 bg-[#141824] border border-[#283044] rounded-lg text-slate-100 text-xs focus:border-[#d4af37] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-slate-300 mb-1">Bureau / Local</label>
                <input
                  type="text"
                  placeholder="Ex: Bureau 104 - Archives"
                  value={bulkBureau}
                  onChange={(e) => setBulkBureau(e.target.value)}
                  className="w-full px-3 py-2 bg-[#141824] border border-[#283044] rounded-lg text-slate-100 text-xs focus:border-[#d4af37] focus:outline-none"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-[#212738]">
              <button
                onClick={() => setShowBulkModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
              >
                Annuler
              </button>
              <button
                onClick={applyBulkChanges}
                className="px-4 py-1.5 text-xs font-semibold text-slate-900 bg-gradient-to-r from-[#d4af37] to-amber-300 hover:from-amber-400 rounded-lg"
              >
                Appliquer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main High-Density Table */}
      <div className="border border-[#202636] rounded-xl overflow-hidden bg-[#0c0e15] shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#121622] border-b border-[#20273a] text-slate-400 font-medium select-none">
                <th className="py-2.5 px-3 w-8 text-center">
                  <input
                    type="checkbox"
                    checked={selectedItemIds.size === filteredItems.length && filteredItems.length > 0}
                    onChange={toggleSelectAll}
                    className="rounded border-[#2c3449] text-[#d4af37] focus:ring-0"
                  />
                </th>
                <th className="py-2.5 px-3">Direction</th>
                <th className="py-2.5 px-3">Bureau / Local</th>
                <th className="py-2.5 px-3">Code Inventaire</th>
                <th className="py-2.5 px-3">Désignation du Bien</th>
                <th className="py-2.5 px-3 text-right">Qté</th>
                <th className="py-2.5 px-3">État</th>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3">Observations</th>
                <th className="py-2.5 px-3 text-center w-20">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b202e]">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-10 text-center text-slate-500">
                    Aucun bien ne correspond aux filtres appliqués.
                  </td>
                </tr>
              ) : (
                filteredItems.map(item => {
                  const isEditing = editingId === item.id;
                  const isSelected = selectedItemIds.has(item.id);

                  if (isEditing && editFormData) {
                    return (
                      <tr key={item.id} className="bg-[#181e2b] border border-[#d4af37]/50">
                        <td className="py-2 px-3 text-center">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#d4af37] mx-auto" />
                        </td>
                        <td className="py-1 px-2">
                          <input
                            type="text"
                            value={editFormData.direction}
                            onChange={(e) => handleEditChange('direction', e.target.value)}
                            className="w-full px-2 py-1 bg-[#0f121a] border border-[#313b52] rounded text-slate-100 text-xs"
                            placeholder="Direction"
                          />
                        </td>
                        <td className="py-1 px-2">
                          <input
                            type="text"
                            value={editFormData.bureau}
                            onChange={(e) => handleEditChange('bureau', e.target.value)}
                            className="w-full px-2 py-1 bg-[#0f121a] border border-[#313b52] rounded text-slate-100 text-xs"
                            placeholder="Bureau"
                          />
                        </td>
                        <td className="py-1 px-2">
                          <input
                            type="text"
                            value={editFormData.code}
                            onChange={(e) => handleEditChange('code', e.target.value)}
                            className="w-full px-2 py-1 bg-[#0f121a] border border-[#313b52] rounded font-mono text-amber-300 text-xs"
                            placeholder="Code"
                          />
                        </td>
                        <td className="py-1 px-2">
                          <input
                            type="text"
                            value={editFormData.designation}
                            onChange={(e) => handleEditChange('designation', e.target.value)}
                            className="w-full px-2 py-1 bg-[#0f121a] border border-[#313b52] rounded text-slate-100 text-xs"
                            placeholder="Désignation"
                          />
                        </td>
                        <td className="py-1 px-2 w-20">
                          <input
                            type="number"
                            min="1"
                            value={editFormData.quantite}
                            onChange={(e) => handleEditChange('quantite', parseFloat(e.target.value) || 1)}
                            className="w-full px-2 py-1 bg-[#0f121a] border border-[#313b52] rounded text-right font-mono text-xs"
                          />
                        </td>
                        <td className="py-1 px-2 w-28">
                          <select
                            value={editFormData.etat}
                            onChange={(e) => handleEditChange('etat', e.target.value)}
                            className="w-full px-2 py-1 bg-[#0f121a] border border-[#313b52] rounded text-xs"
                          >
                            <option value="Bon">Bon</option>
                            <option value="Très bon">Très bon</option>
                            <option value="Moyen">Moyen</option>
                            <option value="Passable">Passable</option>
                            <option value="Mauvais">Mauvais</option>
                            <option value="Hors service">Hors service</option>
                            <option value="En panne">En panne</option>
                            <option value="À réformer">À réformer</option>
                            <option value="Neuf">Neuf</option>
                          </select>
                        </td>
                        <td className="py-1 px-2 w-24">
                          <input
                            type="text"
                            value={editFormData.date}
                            onChange={(e) => handleEditChange('date', e.target.value)}
                            className="w-full px-2 py-1 bg-[#0f121a] border border-[#313b52] rounded text-xs"
                            placeholder="Date"
                          />
                        </td>
                        <td className="py-1 px-2">
                          <input
                            type="text"
                            value={editFormData.observations}
                            onChange={(e) => handleEditChange('observations', e.target.value)}
                            className="w-full px-2 py-1 bg-[#0f121a] border border-[#313b52] rounded text-slate-300 text-xs"
                            placeholder="Observations"
                          />
                        </td>
                        <td className="py-1 px-2 text-center whitespace-nowrap">
                          <button
                            onClick={saveEditing}
                            className="p-1 text-emerald-400 hover:bg-emerald-950/50 rounded mr-1"
                            title="Sauvegarder"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={cancelEditing}
                            className="p-1 text-slate-400 hover:bg-slate-800 rounded"
                            title="Annuler"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-[#121624] transition-colors ${
                        isSelected ? 'bg-[#151a28]' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectOne(item.id)}
                          className="rounded border-[#2c3449] text-[#d4af37] focus:ring-0"
                        />
                      </td>
                      <td className="py-2.5 px-3 text-slate-300 font-medium">
                        {item.direction ? (
                          <span className="truncate max-w-[200px] block" title={item.direction}>
                            {item.direction}
                          </span>
                        ) : (
                          <span className="text-slate-500 italic">— Non spécifiée —</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-slate-300">
                        {item.bureau ? (
                          <span className="truncate max-w-[180px] block" title={item.bureau}>
                            {item.bureau}
                          </span>
                        ) : (
                          <span className="text-slate-500 italic">— Non spécifié —</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-medium text-amber-300 whitespace-nowrap">
                        {item.code || <span className="text-slate-500 font-sans italic">— Sans code —</span>}
                      </td>
                      <td className="py-2.5 px-3 text-slate-100 max-w-xs">
                        <span className="font-medium block truncate" title={item.designation}>
                          {item.designation}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-200">
                        {item.quantite}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-medium border ${
                          item.etat?.toLowerCase().includes('bon') || item.etat?.toLowerCase().includes('neuf')
                            ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800/40'
                            : item.etat?.toLowerCase().includes('moyen') || item.etat?.toLowerCase().includes('passable')
                            ? 'bg-amber-950/40 text-amber-400 border-amber-800/40'
                            : 'bg-red-950/40 text-red-400 border-red-800/40'
                        }`}>
                          {item.etat || 'Bon'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 font-mono text-[11px] whitespace-nowrap">
                        {item.date || '—'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 max-w-[180px] truncate" title={item.observations}>
                        {item.observations || '—'}
                      </td>
                      <td className="py-2.5 px-3 text-center whitespace-nowrap">
                        <button
                          onClick={() => startEditing(item)}
                          className="p-1 text-slate-400 hover:text-amber-300 rounded hover:bg-[#1a2030] transition-colors mr-1"
                          title="Modifier cette ligne"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteItem(item.id)}
                          className="p-1 text-slate-400 hover:text-red-400 rounded hover:bg-[#20171a] transition-colors"
                          title="Supprimer cette ligne"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
