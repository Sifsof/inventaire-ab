import React, { useState, useEffect, useMemo } from 'react';
import { 
  Header 
} from './components/Header';
import { 
  FileUploader 
} from './components/FileUploader';
import { 
  DataVerificationTable 
} from './components/DataVerificationTable';
import { 
  ReconciliationMatrix 
} from './components/ReconciliationMatrix';
import { 
  AnalyticsSummary 
} from './components/AnalyticsSummary';
import { 
  ReportPreviewModal 
} from './components/ReportPreviewModal';
import { 
  ArchiveManagerModal 
} from './components/ArchiveManagerModal';
import { 
  InventoryItem, 
  CommissionInfo, 
  MatchPair, 
  ReconciliationSummary, 
  AuditSession 
} from './types/inventory';
import { 
  reconcileInventories 
} from './utils/matcher';
import { 
  DEMO_ITEMS_A, 
  DEMO_ITEMS_B, 
  DEMO_COMMISSION_A, 
  DEMO_COMMISSION_B 
} from './utils/demoData';
import { 
  Layers, 
  FileSpreadsheet, 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRightLeft, 
  Building2, 
  FileCheck,
  Download
} from 'lucide-react';
import { exportReconciliationToExcel, exportReconciliationToWord, exportReconciliationToPdf } from './utils/exporters';

export default function App() {
  // Inventory items
  const [itemsA, setItemsA] = useState<InventoryItem[]>([]);
  const [itemsB, setItemsB] = useState<InventoryItem[]>([]);
  const [fileNameA, setFileNameA] = useState<string>('');
  const [fileNameB, setFileNameB] = useState<string>('');
  const [fileTypeA, setFileTypeA] = useState<string>('');
  const [fileTypeB, setFileTypeB] = useState<string>('');
  const [commissionA, setCommissionA] = useState<CommissionInfo>({ detected: false, membres: [], rawTextLines: [] });
  const [commissionB, setCommissionB] = useState<CommissionInfo>({ detected: false, membres: [], rawTextLines: [] });

  // Navigation tab
  const [activeTab, setActiveTab] = useState<'reconciliation' | 'groupA' | 'groupB' | 'report' | 'archives'>('reconciliation');

  // Custom Icon & Local Storage Archives
  const [customIcon, setCustomIcon] = useState<string>(() => {
    try {
      return localStorage.getItem('aureainventaire_icon') || '';
    } catch {
      return '';
    }
  });

  const [archives, setArchives] = useState<AuditSession[]>(() => {
    try {
      const stored = localStorage.getItem('aureainventaire_archives');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isArchiveModalOpen, setIsArchiveModalOpen] = useState(false);

  // Manual pairs overrides tracker
  const [manualPairs, setManualPairs] = useState<Map<string, MatchPair>>(new Map());

  // Save custom icon to localStorage
  const handleCustomIconChange = (dataUrl: string) => {
    setCustomIcon(dataUrl);
    try {
      localStorage.setItem('aureainventaire_icon', dataUrl);
    } catch (e) {
      console.warn("Storage full", e);
    }
  };

  // Run reconciliation algorithm
  const { pairs, summary } = useMemo(() => {
    if (itemsA.length === 0 && itemsB.length === 0) {
      return {
        pairs: [],
        summary: {
          totalItemsA: 0,
          totalQuantiteA: 0,
          totalItemsB: 0,
          totalQuantiteB: 0,
          totalUniqueAssets: 0,
          conformeCount: 0,
          ecartQuantiteCount: 0,
          ecartEtatCount: 0,
          absentACount: 0,
          absentBCount: 0,
          doublonCount: 0,
          aVerifierCount: 0,
          tauxConcordance: 0,
          tauxIdentification: 0,
          methodologieCalcul: "Aucune donnée importée.",
          causesProbables: [],
          recommandations: []
        } as ReconciliationSummary
      };
    }

    const res = reconcileInventories(itemsA, itemsB);

    // Apply any manual user overrides
    if (manualPairs.size > 0) {
      const updatedPairs = res.pairs.map(p => {
        if (manualPairs.has(p.id)) {
          return manualPairs.get(p.id)!;
        }
        return p;
      });
      return {
        pairs: updatedPairs,
        summary: res.summary
      };
    }

    return res;
  }, [itemsA, itemsB, manualPairs]);

  // Handle single pair update (e.g. manual validation in matrix)
  const handleUpdatePair = (updatedPair: MatchPair) => {
    const next = new Map(manualPairs);
    next.set(updatedPair.id, updatedPair);
    setManualPairs(next);
  };

  // Load Demonstration Case Study
  const handleLoadDemo = () => {
    setItemsA(DEMO_ITEMS_A);
    setItemsB(DEMO_ITEMS_B);
    setFileNameA('Inventaire_Comptable_DAF_DSI_DRH_2024.xlsx');
    setFileNameB('Recensement_Physique_Terrain_2026.docx');
    setFileTypeA('Excel');
    setFileTypeB('Word');
    setCommissionA(DEMO_COMMISSION_A);
    setCommissionB(DEMO_COMMISSION_B);
    setManualPairs(new Map());
    setActiveTab('reconciliation');
  };

  // Reset workspace
  const handleReset = () => {
    if (confirm("Voulez-vous réinitialiser l'espace de travail ? Vos fichiers d'origine sur votre ordinateur ne seront pas modifiés.")) {
      setItemsA([]);
      setItemsB([]);
      setFileNameA('');
      setFileNameB('');
      setFileTypeA('');
      setFileTypeB('');
      setCommissionA({ detected: false, membres: [], rawTextLines: [] });
      setCommissionB({ detected: false, membres: [], rawTextLines: [] });
      setManualPairs(new Map());
      setActiveTab('reconciliation');
    }
  };

  // Archive current session
  const handleArchive = () => {
    const titlePrompt = prompt("Nom de la session d'inventaire à archiver :", `Audit_${fileNameA || 'A'}_vs_${fileNameB || 'B'}_${new Date().toLocaleDateString('fr-FR')}`);
    if (!titlePrompt) return;

    const newSession: AuditSession = {
      id: `session-${Date.now()}`,
      title: titlePrompt,
      savedAt: new Date().toISOString(),
      fileNameA,
      fileNameB,
      fileTypeA,
      fileTypeB,
      itemsA,
      itemsB,
      commissionA,
      commissionB,
      pairs,
      summary,
      customIcon
    };

    const updatedArchives = [newSession, ...archives];
    setArchives(updatedArchives);
    try {
      localStorage.setItem('aureainventaire_archives', JSON.stringify(updatedArchives));
      alert("Session archivée avec succès dans le stockage local !");
    } catch (e) {
      alert("Espace de stockage local saturé. Vous pouvez télécharger l'archive JSON depuis l'onglet Archives.");
    }
  };

  // Restore past session
  const handleRestoreArchive = (session: AuditSession) => {
    setItemsA(session.itemsA);
    setItemsB(session.itemsB);
    setFileNameA(session.fileNameA);
    setFileNameB(session.fileNameB);
    setFileTypeA(session.fileTypeA);
    setFileTypeB(session.fileTypeB);
    setCommissionA(session.commissionA || { detected: false, membres: [], rawTextLines: [] });
    setCommissionB(session.commissionB || { detected: false, membres: [], rawTextLines: [] });
    if (session.customIcon) setCustomIcon(session.customIcon);
    setManualPairs(new Map());
    setIsArchiveModalOpen(false);
    setActiveTab('reconciliation');
  };

  // Delete archive
  const handleDeleteArchive = (id: string) => {
    if (confirm("Supprimer cette archive locale ?")) {
      const updated = archives.filter(a => a.id !== id);
      setArchives(updated);
      localStorage.setItem('aureainventaire_archives', JSON.stringify(updated));
    }
  };

  // Import JSON archive
  const handleImportArchive = (session: AuditSession) => {
    handleRestoreArchive(session);
    const updated = [session, ...archives.filter(a => a.id !== session.id)];
    setArchives(updated);
    localStorage.setItem('aureainventaire_archives', JSON.stringify(updated));
    alert("Archive importée et restaurée avec succès !");
  };

  const hasData = itemsA.length > 0 || itemsB.length > 0;

  return (
    <div className="min-h-screen bg-[#07080c] text-slate-100 flex flex-col font-sans selection:bg-[#d4af37]/30 selection:text-amber-200">
      
      {/* Top Navbar */}
      <Header
        activeTab={activeTab}
        setActiveTab={(t) => {
          if (t === 'report') setIsReportModalOpen(true);
          else if (t === 'archives') setIsArchiveModalOpen(true);
          else setActiveTab(t);
        }}
        countA={itemsA.length}
        countB={itemsB.length}
        concordanceRate={summary.tauxConcordance}
        hasData={hasData}
        onReset={handleReset}
        onArchive={handleArchive}
        onLoadDemo={handleLoadDemo}
        onOpenReport={() => setIsReportModalOpen(true)}
        customIcon={customIcon}
        onCustomIconChange={handleCustomIconChange}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">

        {/* View 1: Main Reconciliation View */}
        {activeTab === 'reconciliation' && (
          <div className="space-y-6">

            {/* If no data yet: Hero callout with 1-click Demo */}
            {!hasData && (
              <div className="p-8 rounded-2xl bg-gradient-to-br from-[#121624] via-[#0d1019] to-[#08090f] border border-[#d4af37]/30 shadow-2xl relative overflow-hidden">
                <div className="max-w-3xl space-y-3">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#d4af37]/15 border border-[#d4af37]/40 text-[#dfb743] text-xs font-mono font-semibold">
                    <ShieldCheck className="w-4 h-4 text-[#dfb743]" />
                    Audit et Rapprochement Patrimonial 100% Hors-Ligne
                  </div>
                  <h1 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-gold-gradient">
                    Rapprochement et Comparaison des Inventaires A/B
                  </h1>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    Comparez deux états d'inventaire (registre comptable théorique vs recensement physique terrain) en formats <strong>Excel, Word et PDF</strong>. 
                    Tous les calculs, l'extraction des hiérarchies (directions et bureaux) et la reconnaissance optique (OCR) s'exécutent <strong>strictement en local</strong> dans votre navigateur sans aucune connexion Internet.
                  </p>
                  <div className="pt-2 flex items-center gap-3 flex-wrap">
                    <button
                      onClick={handleLoadDemo}
                      className="px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-[#d4af37] via-amber-300 to-amber-200 hover:from-amber-400 hover:to-amber-100 rounded-lg shadow-lg transition-all flex items-center gap-2"
                    >
                      <Sparkles className="w-4 h-4" />
                      Charger l'Exemple Réaliste (Direction & Bureaux)
                    </button>
                    <span className="text-xs text-slate-500">
                      ou glissez-déposez vos deux fichiers ci-dessous.
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Side-by-side Uploaders */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <FileUploader
                groupName="Groupe A"
                groupSubtitle="Référentiel de base (Ex: Registre comptable, fichier théorique)"
                items={itemsA}
                commission={commissionA}
                fileName={fileNameA}
                onDataLoaded={(newItems, comm, name, type) => {
                  setItemsA(newItems);
                  setCommissionA(comm);
                  setFileNameA(name);
                  setFileTypeA(type);
                  setManualPairs(new Map());
                }}
                onClear={() => {
                  setItemsA([]);
                  setFileNameA('');
                  setCommissionA({ detected: false, membres: [], rawTextLines: [] });
                  setManualPairs(new Map());
                }}
                onViewItems={() => setActiveTab('groupA')}
              />

              <FileUploader
                groupName="Groupe B"
                groupSubtitle="Recensement de contrôle (Ex: Inventaire physique terrain, récolement)"
                items={itemsB}
                commission={commissionB}
                fileName={fileNameB}
                onDataLoaded={(newItems, comm, name, type) => {
                  setItemsB(newItems);
                  setCommissionB(comm);
                  setFileNameB(name);
                  setFileTypeB(type);
                  setManualPairs(new Map());
                }}
                onClear={() => {
                  setItemsB([]);
                  setFileNameB('');
                  setCommissionB({ detected: false, membres: [], rawTextLines: [] });
                  setManualPairs(new Map());
                }}
                onViewItems={() => setActiveTab('groupB')}
              />
            </div>

            {/* When data is present: Analytics & Comparison Matrix */}
            {hasData && (
              <div className="space-y-6 pt-2">
                
                {/* Export toolbar */}
                <div className="flex items-center justify-between p-3.5 bg-[#0f121d] rounded-xl border border-[#23293c] flex-wrap gap-3">
                  <div className="flex items-center gap-2">
                    <span className="font-serif font-bold text-xs text-amber-300">
                      Rapports de Rapprochement
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {pairs.length} références croisées · Concordance {summary.tauxConcordance}%
                    </span>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      onClick={() => setIsReportModalOpen(true)}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-900 bg-gradient-to-r from-[#d4af37] to-amber-300 hover:from-amber-400 rounded-lg shadow transition-all flex items-center gap-1.5"
                    >
                      <FileCheck className="w-3.5 h-3.5" />
                      Aperçu Officiel & A4
                    </button>

                    <button
                      onClick={() => exportReconciliationToExcel(pairs, summary, itemsA, itemsB, commissionA, commissionB)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#151926] hover:bg-[#1d2334] border border-[#2b3348] rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                      Excel (.xlsx)
                    </button>

                    <button
                      onClick={() => exportReconciliationToWord(pairs, summary, commissionA, commissionB)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#151926] hover:bg-[#1d2334] border border-[#2b3348] rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5 text-blue-400" />
                      Word (.docx)
                    </button>

                    <button
                      onClick={() => exportReconciliationToPdf(pairs, summary, commissionA, commissionB)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#151926] hover:bg-[#1d2334] border border-[#2b3348] rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5 text-red-400" />
                      PDF (.pdf)
                    </button>
                  </div>
                </div>

                {/* KPI & Summary Section */}
                <AnalyticsSummary summary={summary} />

                {/* Matrice de Correspondance */}
                <div className="pt-2">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h2 className="font-serif text-base font-bold text-slate-100 flex items-center gap-2">
                        <ArrowRightLeft className="w-4 h-4 text-[#dfb743]" />
                        Matrice de Concordance et Détection des Écarts
                      </h2>
                      <p className="text-xs text-slate-400">
                        Rapprochement par emplacement (Direction et Bureau), priorisant le code d'inventaire puis la similarité lemmatique.
                      </p>
                    </div>
                  </div>

                  <ReconciliationMatrix
                    pairs={pairs}
                    onUpdatePair={handleUpdatePair}
                  />
                </div>

              </div>
            )}

          </div>
        )}

        {/* View 2: Group A Inspection & Editing */}
        {activeTab === 'groupA' && (
          <DataVerificationTable
            groupTitle="Groupe A"
            items={itemsA}
            onUpdateItems={(updated) => setItemsA(updated)}
            onBackToComparison={() => setActiveTab('reconciliation')}
          />
        )}

        {/* View 3: Group B Inspection & Editing */}
        {activeTab === 'groupB' && (
          <DataVerificationTable
            groupTitle="Groupe B"
            items={itemsB}
            onUpdateItems={(updated) => setItemsB(updated)}
            onBackToComparison={() => setActiveTab('reconciliation')}
          />
        )}

      </main>

      {/* Official A4 Report Preview Modal */}
      <ReportPreviewModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        pairs={pairs}
        summary={summary}
        itemsA={itemsA}
        itemsB={itemsB}
        commissionA={commissionA}
        commissionB={commissionB}
        customIcon={customIcon}
      />

      {/* Local Archives Modal */}
      <ArchiveManagerModal
        isOpen={isArchiveModalOpen}
        onClose={() => setIsArchiveModalOpen(false)}
        archives={archives}
        onRestoreArchive={handleRestoreArchive}
        onDeleteArchive={handleDeleteArchive}
        onImportArchive={handleImportArchive}
      />

      {/* Clean Footer */}
      <footer className="no-print mt-auto border-t border-[#1a1f2e] bg-[#080a10] py-4 text-center text-xs text-slate-500">
        <div className="max-w-[1600px] mx-auto px-4 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 text-slate-400">
            <span className="font-serif font-bold text-gold-gradient">AureaInventaire</span>
            <span>·</span>
            <span>Traitement 100% Local & Hors-Ligne (Aucun transfert cloud)</span>
          </div>
          <div>
            Conforme aux normes d'audit patrimonial et de récolement contradictoire
          </div>
        </div>
      </footer>

    </div>
  );
}
